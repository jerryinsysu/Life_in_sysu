#include<iostream>
#include<stdint.h>

using namespace std;

//128���ص�������������uint64_t����
class BigInt
{
public:
    uint64_t hi;//��λ
    uint64_t lo;//��λ
    BigInt() :hi(0), lo(0) {};//���캯��
    BigInt(uint64_t h, uint64_t l)//����ת�����캯��(Ĭ��Ϊ������)
    {
        hi = h;
        lo = l;
    }
public:
    BigInt operator+(const BigInt& rhs);//�ӷ���������
    BigInt operator*(const BigInt& rhs);//�˷��������أ��涨���Ҳ�������С�ڵ���64λ
    BigInt operator%(const BigInt& rhs);//����������أ��涨�Ҳ�����Ϊ64λ
    BigInt operator-(const BigInt& rhs);//������������

};

int compare(BigInt a, BigInt b) {//��ȷ���0��a > b����1��a < b����-1
    if (a.hi == b.hi) {
        if (a.lo == b.lo) return 0;
        return a.lo > b.lo ? 1 : -1;
    }
    return a.hi > b.hi ? 1 : -1;
}

BigInt rightshift(BigInt a, int k) {
    a.lo >>= k;
    a.lo |= a.hi << (64 - k);
    a.hi >>= k;
    return a;
}

BigInt leftshift(BigInt a, int k) {
    a.hi <<= k;
    a.hi |= a.lo >> (64 - k);
    a.lo <<= k;
    return a;
}

BigInt BigInt::operator*(const BigInt& rhs) {
    uint64_t a_lo = (uint32_t)lo;
    uint64_t a_hi = lo >> 32;
    uint64_t b_lo = (uint32_t)rhs.lo;
    uint64_t b_hi = rhs.lo >> 32;

    uint64_t    a_x_b_hi = a_hi * b_hi;
    uint64_t    a_x_b_mid = a_hi * b_lo;
    uint64_t    b_x_a_mid = b_hi * a_lo;
    uint64_t    a_x_b_lo = a_lo * b_lo;

    uint64_t    carry_bit = ((uint64_t)(uint32_t)a_x_b_mid +
        (uint64_t)(uint32_t)b_x_a_mid +
        (a_x_b_lo >> 32)) >> 32;

    uint64_t  multhi = a_x_b_hi +
        (a_x_b_mid >> 32) + (b_x_a_mid >> 32) +
        carry_bit;

    return BigInt(multhi, lo * rhs.lo);
}

BigInt BigInt::operator%(const BigInt& rhs) {

    BigInt X = rhs;
    BigInt A_2 = rightshift(*this, 1);
    BigInt A = *this;
    while (compare(X, A_2) != 1) {
        X = leftshift(X, 1);
    }

    while (compare(X, rhs) != -1) {
        if (compare(A, X) != -1) A = A - X;
        X = rightshift(X, 1);
    }
    return A;
}

BigInt BigInt::operator+(const BigInt& rhs) {//�涨�ұ�С�����
    bool carry = (UINT64_MAX - this->lo < rhs.lo);
    BigInt res;
    res.lo = this->lo + rhs.lo;
    res.hi = this->hi + rhs.hi;
    if (carry) res.hi += 1;
    return res;
}

BigInt BigInt::operator-(const BigInt& rhs) {//�涨�������
    BigInt res;
    if (this->lo < rhs.lo) {
        res.lo = UINT64_MAX - rhs.lo + 1;
        res.lo += this->lo;
        res.hi = this->hi - rhs.hi - 1;
    }
    else {
        res.lo = this->lo - rhs.lo;
        res.hi = this->hi - rhs.hi;
    }
    return res;
}

BigInt QuickPowM(BigInt a, BigInt e, BigInt p) {
    BigInt zero(0, 0);
    BigInt ans(0, 1);
    while (compare(zero, e) != 0) {
        if (e.lo & 1) ans = (ans * a) % p;
        a = (a * a) % p;
        e = rightshift(e, 1);
    }
    return ans;
}

int main() {

    uint64_t p, g, s;
    string ans;
    int cnt = 0;
    int n;
    cin >> p >> g >> s >> n;
    BigInt pp(0, p), gg(0, g), ss(0, s);
    BigInt edge = rightshift(pp, 1);
    for (int i = 0; i < n; ++i) {
        ss = QuickPowM(gg, ss, pp);;
        if (compare(ss, edge) != -1) {
            ans += '1';
            ++cnt;
        }
        else ans += '0';
    }
    cout << ans << endl;
    cout << n - cnt << endl;
    cout << cnt << endl;

    return 0;
}