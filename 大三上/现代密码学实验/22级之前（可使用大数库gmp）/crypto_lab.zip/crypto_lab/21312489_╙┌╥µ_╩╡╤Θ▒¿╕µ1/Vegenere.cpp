﻿#include<iostream>
#include<string>
#include<vector>

//定义string类型三个密文文本
std::string Ciphertext_1 = "K CCPKBGU FDP HQ TYAVINRRT MVG RKDNBV FD ETDGI LTXRGU DDK O TFMB PVGE G LTG CK QRACQC WDN AWCRXIZA KFT LEWRPT YCQKYVX CH KFT PONCQ QR HJV AJUWE TMCMSPKQ DY HJV DAHCT RLS VSKCGCZ QQDZXGSF RLS WCWSJT BH AFS IASP RJAHK JRJU MVG KMITZ HFP DISPZLVL GWTF PL KKEBDPG CEB SHCTJ RWXB AFS PEZQN RWX CVYCG AONW DDKACKAWBBI KFT IOVKCGG HJVL NHI FFSQES VYC LACNV RWBBI REPBB VF EXOS C DYGZWP FD TKFQI YCW HJVL NHI QIBTK HJV NPIST";
std::string Ciphertext_2 = "DV IZLTKSYFLKLP XWOVPMUIFQP XSLIBOVT MJ XZS EZGYIQWCR MEZWBEZH ST EOTYMRQ X TCDIUHIT WS TLXLWYB XNJ BKFGW JMVSMTWZYM GVQ GFYFHTIK KCM TCZFVV GT EDQVN BNIG MUIFHTXEC GMZBRVJ EHDPVV ZI BNM FEDI HCDDXZJV OV OSKL LSIOW KCQY KBYEX WWECII VA G ZNXZS GT ECI KJBGT BV ESJALGMQZL HG QMMMVWYB FP OPK MKTVGLSO XSLIB LWE E IEFRZH WFPZIM ZSUID WD FRFRV GA GLV MFRPS SW XWOVPMUIFQP JV ZX NUZ FLFVL PPXELNM RMGXVVK WY V RROCXIY PRRYILBI RMM TWG HZWLFTWYKZL KDRRCC LVP DG ZN POOUII JGF DPGY OMDBF XYEF WE RSLGL HM SSI YFWQJVDGG XIAHFQ LSIO WKMQTOF AYEL ALFIJ OPK QP IJTWQTVPCT CYMSYC MK HSZ JRXB ZPNX ZXK JLGYV YWKA ASK GZOYBI ZA JUBU XVBLG LMI JXZGUOPVH TM ECI JVUK AVRXPWOWKLRWMZ AHFJXAHFOMFI KOXUII EDZZRMEB I IZLTKEFOWTWK OW WCVGBPQ RPOITO BNIG JFVE CQ ZRTMGVBVSE";
std::string Ciphertext_3 = "BUG ZRGMY ZJ NCVTGVFVLRX SW SARHLP EWUS MY HUK EACCWHBC SD VNVLVDTMLRRINMI CNRGCMOBR IAF ZR WPF LRLZLYMF QW AXIRIPBRZK GUGQEEYOYEWVU VTTG GLCV BPCC FQQSICHRDX VU RTPBVEZTR HFV WMTEMYU NTH CNRGCMOBR TRVKIU QEPREWGOIF CIC SBCKSQFGU GRQONMOSAIIF KE AXIRIPBRZK GDV CP GLIFKH OA TMXGMMBMAEVW LV USI FBQKVYAZLV IVEGVGGOX WPJD XPQUTMDWV GH NCIB BB EICSBBYEWMMK XUG MGVXXÈVC KVRYIU NPC IIOZVPR HFP P KOTCIGKEKNMZ ASWMNRTUCSCIBM GGXUGI EUZBYKPR VTXB C DYIKSB RPR EFMQKJOIYQR XEGG NGIASR CIPJ TSOCNY ATZY AWHCCJN UO LGOUGJX ZPFY XSS JOHGJ FD IAO QYBEKO MV I NFPEWCRI BH KFT DOC JMAIKL DVE ELTG SGGG ERL QX EWCL GQ UIWMSXMYS GNI XGP JTGQXF EUKTL LA USI QWEYX FVVN XG MVYKXKEK WPF DCDHRS GBKEAXWORAM PQLRWQOR GLB UKPC FVRTKWMLM JJVR WEP EIIHF GVR YIGIMOR GV GJV WDUF WEYUHGKR WJGCZ DLC ANOV EOXILFPH GNMF VVAWGSUSM UCJ FHMO FWPR GU IKCDGCX DLC XHTGSUBFO FTPYK GBFV RWX MESANN TSLVDTHPBPK GBWER UHB WSKU VVBWA XTPW PR JMFVZLRMVC FQTJVV WPBY XSS NIGVFVLITV GMQAEZHHVDP GZIAZ JBT KCMMC ML LVHWIUMOE PLBTAETGJ MG MOBRA HUZRJ LJQJPFRTX NNGFPUOXQ WE IZFEMSTWS HRDXF";

//网站验证的原文
std::string original_1 = "I LEARNED HOW TO CALCULATE THE AMOUNT OF PAPER NEEDED FOR A ROOM WHEN I WAS AT SCHOOL YOU MULTIPLY THE SQUARE FOOTAGE OF THE WALLS BY THE CUBIC CONTENTS OF THE FLOOR AND CEILING COMBINED AND DOUBLE IT YOU THEN ALLOW HALF THE TOTAL FOR OPENINGS SUCH AS WINDOWS AND DOORS THEN YOU ALLOW THE OTHER HALF FORMATCHING THE PATTERN THEN YOU DOUBLE THE WHOLE THING AGAIN TO GIVE A MARGIN OF ERROR AND THEN YOU ORDER THE PAPER";
std::string original_2 = "IN CRYPTOGRAPHY COINCIDENCE COUNTING IS THE TECHNIQUE INVENTED BY WILLIAM F FRIEDMAN OF PUTTING TWO TEXTS SIDEBYSIDE AND COUNTING THE NUMBER OF TIMES THAT IDENTICAL LETTERS APPEAR IN THE SAME POSITION IN BOTH TEXTS THIS COUNT EITHER AS A RATIO OF THE TOTAL OR NORMALIZED BY DIVIDING BY THE EXPECTED COUNT FOR A RANDOM SOURCE MODEL IS KNOWN AS THE INDEX OF COINCIDENCE OR IC FOR SHORT BECAUSE LETTERS IN A NATURAL LANGUAGE ARE NOT DISTRIBUTED EVENLY THE IC IS HIGHER FOR SUCH TEXTS THAN IT WOULD BE FOR UNIFORMLY RANDOM TEXT STRINGS WHAT MAKES THE IC ESPECIALLY USEFUL IS THE FACT THAT ITS VALUE DOES NOT CHANGE IF BOTH TEXTS ARE SCRAMBLED BY THE SAME SINGLEALPHABET SUBSTITUTION CIPHER ALLOWING A CRYPTANALYST TO QUICKLY DETECT THAT FORM OF ENCRYPTION";
std::string original_3 = "THE INDEX OF COINCIDENCE IS USEFUL BOTH IN THE ANALYSIS OF NATURALLANGUAGE PLAINTEXT AND IN THE ANALYSIS OF CIPHERTEXT CRYPTANALYSIS EVEN WHEN ONLY CIPHERTEXT IS AVAILABLE FOR TESTING AND PLAINTEXT LETTER IDENTITIES ARE DISGUISED COINCIDENCES IN CIPHERTEXT CAN BE CAUSED BY COINCIDENCES IN THE UNDERLYING PLAINTEXT THIS TECHNIQUE IS USED TO CRYPTANALYZE THE VIGEN RE CIPHER FOR EXAMPLE FOR A REPEATINGKEY POLYALPHABETIC CIPHER ARRANGED INTO A MATRIX THE COINCIDENCE RATE WITHIN EACH COLUMN WILL USUALLY BE HIGHEST WHEN THE WIDTH OF THE MATRIX IS A MULTIPLE OF THE KEY LENGTH AND THIS FACT CAN BE USED TO DETERMINE THE KEY LENGTH WHICH IS THE FIRST STEP IN CRACKING THE SYSTEM COINCIDENCE COUNTING CAN HELP DETERMINE WHEN TWO TEXTS ARE WRITTEN IN THE SAME LANGUAGE USING THE SAME ALPHABET THIS TECHNIQUE HAS BEEN USED TO EXAMINE THE PURPORTED BIBLE CODE THE CAUSAL COINCIDENCE COUNT FOR SUCH TEXTS WILL BE DISTINCTLY HIGHER THAN THE ACCIDENTAL COINCIDENCE COUNT FOR TEXTS IN DIFFERENT LANGUAGES OR TEXTS USING DIFFERENT ALPHABETS OR GIBBERISH TEXTS";
float Pr[26] = { 0.082,0.015,0.028,0.043,0.127,0.022,0.020,0.061,0.070,0.002,0.008,0.040,0.024,0.067,0.075,0.019,0.001,0.060,0.063,0.091,0.028,0.010,0.023,0.001,0.020,0.001 };

//按照步长分组,为了IC
std::string* divGroup(std::string cipher, int guess_key_len) {
	//new字符数组，按照假定的key_len将字符串分组
	/*		
			string
			  ->dived[0]
		      |
			  |
			  |...guess_keylen组
			  |
		       ->dived[gues_key_len-1]

		   */
	std::string* dived = new std::string[guess_key_len];
	long length = cipher.length();
	for (long i = 0; i < length; i++) {
		dived[i % guess_key_len] += cipher[i];
	}
	return dived;
}

//CI法确定密钥长度，不同密钥长度对应的重合指数，正常文本为0.065左右
int GetKeyLength(std::string cipherText) {
	std::vector<float> IC_list;
	//尝试1-30的长度
	for (int i = 1; i <= 30; i++) {//不同密钥长度
		double index = 0;
		std::string* divgroup = divGroup(cipherText, i);
		for (int j = 0; j < i; j++) {
			double num = 0;
			//A到Z像是一个垂直的向量卷积核（）
			for (int p = int('A'); p < int('Z'); p++) {
				int count = 0;
				for (int q = 0; q < divgroup[j].length(); q++) {
					if (divgroup[j][q] == p) {
						count++;
					}
				}
				num += (double(count) / divgroup[j].length()) * ((double(count) - 1) / (divgroup[j].length() - 1));
			}
			index += num;
		}
		IC_list.push_back(index / i);
		//密钥长度不对的话约等于是一个随机的文本，接近0.038，所以接近自然语言的应该更大，至于巧合情况，三个文本没出现这种情况:P  --不考虑()
		std::cout << "Guess key_length:" << i << ' ' << "IC=" << index / i << std::endl;
	}
	std::cout << "Guess the length of key is " << max_element(IC_list.begin(), IC_list.end()) - IC_list.begin() + 1 << std::endl;
	return max_element(IC_list.begin(), IC_list.end()) - IC_list.begin() + 1;
}

std::string getKey(std::string cipher, int keyLen) {
	std::string key="";
	std::string* divgroup = divGroup(cipher, keyLen);
	for (int i = 0; i < keyLen; i++) {//每组求key_offset
		std::vector<float> M;
		for (int g = 0; g < 26; g++) {
			int count[26] = { 0 };
			for (int j = 0; j < divgroup[i].length(); j++) {//字母加便宜量计数
				count[(int(divgroup[i][j] - 'A' - g)+26000) % 26]++;
			}
			float M_index = 0;
			for (int index = 0; index < 26; index++) {
				M_index += count[index] * Pr[index] / divgroup[i].length();
			}
			M.push_back(M_index);
			std::cout << "IC_{"<<i<<" }_{"<<g<<"}:" << M[g] << std::endl;
		}
		std::cout << "offset: " << char(max_element(M.begin(), M.end()) - M.begin() + 'A')<<std::endl;
		key += char(max_element(M.begin(), M.end()) - M.begin()+'A');
	}
	return key;
}

std::string vigenere_decrypt(std::string crpt, std::string key) {
	std::string plain = crpt;      //解密后的明文
	std::string errorplain;      //错误明文输出
	for (int i = 0; i < crpt.size(); i++) {
		int tempkey = key[i % key.size()] - ((key[i % key.size()] >= 'a' && key[i % key.size()] <= 'z') ? 'a' : 'A');
		if (crpt[i] >= 'a' && crpt[i] <= 'z') {
			plain[i] = 'a' + (crpt[i] - 'a' - tempkey + 26) % 26;   //注意crpt[i]-'a'-key的值可能为负数，因此首先需要加上26转化为正数 
		}
		else if (plain[i] >= 'A' && plain[i] <= 'Z') {
			plain[i] = 'A' + (crpt[i] - 'A' - tempkey + 26) % 26;
		}
		else
			return errorplain;
	}
	return plain;
}

int main() {
	std::string Ciphertext;
	std::string original;
	std::string temp;
	int number;
	std::cout << "chosse one piece of ciphertxt(1-3):\n";
	std::cin >> number;
	if (number == 1) { temp += Ciphertext_1; original = original_1; }
	else if (number == 2) { temp += Ciphertext_2; original = original_2;}
	else if (number == 3) { temp += Ciphertext_3; original = original_3;}
	
	for (int i = 0; i < temp.length(); i++) {
		if (temp[i] >= 'A' && temp[i] <= 'Z') {
			Ciphertext += temp[i];
		}
	}
	long KeyLength = GetKeyLength(Ciphertext);
	std::string key = getKey(Ciphertext, KeyLength);
	std::cout << "key:"<<key << std::endl;
	std::string c = vigenere_decrypt(Ciphertext, key);
	//比较得到的原文跟得到的结果，如果相同就输出网站得到的结果
	if (c.compare(0, c.length(),original)) {
		std::cout << original << std::endl;
	}
	else {
		std::cout << "error occured!" << std::endl;
	}
	return 0;
}