#include<iostream>
#include<vector>
using namespace std;

vector<vector<int>> mult(vector<vector<int>> matrix1, vector<vector<int>> matrix2) {
	vector<vector<int>> matrix;
	for (int i = 0; i < matrix1.size(); i++) {
		vector<int> temp;
		for (int j = 0; j < matrix2[i].size(); j++) {
			double sum = 0;
			for (int k = 0; k < matrix2[i].size(); k++)
				sum += matrix1[i][k] * matrix2[k][j];
			temp.push_back(((int(sum) + 26) % 26+26)%26);
		}
		matrix.push_back(temp);
	}
	return matrix;
}
//��þ�����˵�һ�У�λ����i����
vector<int> get_multed_row(vector<vector<int>> matrix1, vector<vector<int>> matrix2, int i) {
	vector<int> temp;
	for (int j = 0; j < matrix2[i].size(); j++) {
		double sum = 0;
		for (int k = 0; k < matrix2[i].size(); k++)
			sum += matrix1[i][k] * matrix2[k][j];
		temp.push_back(((int(sum)) % 26 + 26) % 26);
	}
	return temp;
}

int main() {
	string known = "adisplayedequation";
	string unknown = "DSRMSIOPLXLJBZULLM";
	vector<vector<int>> x, y;
	int flag = 0;
	for (int i = 0; i < 3; i++) {
		vector<int> temp;
		for (int j = 0; j < 3; j++) {
			temp.push_back((int(known[flag + 9] - known[flag])%26+26) %26);
			flag++;
		}
		y.push_back(temp);
	}
	flag = 0;
	for (int i = 0; i < 3; i++) {
		vector<int> temp;
		for (int j = 0; j < 3; j++) {
			temp.push_back((int(unknown[flag + 9] - unknown[flag])%26+26)%26);
			flag++;
		}
		x.push_back(temp);
	}
	cout << "X1-X2�ľ���" << '\n';
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++) {
			cout << y[i][j] << " ";
		}
		cout << '\n';
	}
	cout << '\n';

	vector<vector<int>> ans(3,vector<int>(3));

	//vector<vector<int>> I{  { 1, 0, 0 },
	//						{ 0, 1, 0 },
	//						{ 0, 0, 1 } };//���쵥λ��
	//�����������
	vector<vector<int>> b(3, vector<int>(3));
	for (int i = 0; i < 26; i++) {
		for (int j = 0; j < 26; j++) {
			for (int k = 0; k < 26; k++) {
				b[0][0] = i;
				b[0][1] = j;
				b[0][2] = k;
				vector<int> check = get_multed_row(b,y, 0);
				if (check[0] == 1 && check[1] == 0 && check[2] == 0) {
					ans[0][0] = i, ans[0][1] = j, ans[0][2] = k;
					goto lab1;
				}
				else continue;
			}
		}
	}
lab1:
	for (int i = 0; i < 26; i++) {
		for (int j = 0; j < 26; j++) {
			for (int k = 0; k < 26; k++) {
				b[1][0] = i;
				b[1][1] = j;
				b[1][2] = k;
				vector<int> check = get_multed_row(b,y, 1);
				if (check[0] == 0 && check[1] == 1 && check[2] == 0) {
						ans[1][0] = i, ans[1][1] = j, ans[1][2] = k;
					goto lab2;
				}
			}
		}
	}
lab2:
	for (int i = 0; i < 26; i++) {
		for (int j = 0; j < 26; j++) {
			for (int k = 0; k < 26; k++) {
				b[2][0] = i;
				b[2][1] = j;
				b[2][2] = k;
				vector<int> check = get_multed_row(b,y, 2);
				if (check[0] == 0 && check[1] == 0 && check[2] == 1) {
					ans[2][0] = i, ans[2][1] = j, ans[2][2] = k;
					goto lab3;
				}

			}
		}
	}
lab3:
	cout<<"��֤������ԭ���ľ���y�˻�Ϊ1:\n";
	
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++) {
			cout << mult(ans, y)[i][j]<<"  ";
		}
		cout << '\n';
	}
	cout << '\n';
	

	cout << "X1-X2�����Ϊ��\n";
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			cout << ans[i][j] << " ";
		}
		cout << '\n';
	}
	cout << '\n';
	
	ans = mult(ans, x);//L
	cout << "��Կ����Ϊ��\n";
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++) {
			cout << ans[i][j] << " ";
		}
		cout << '\n';
	}
	cout << '\n';

	vector<vector<int>> min, mi;
	flag = 0;
	for (int i = 0; i < 3; i++) {
		vector<int> temp;
		for (int j = 0; j < 3; j++) {
			temp.push_back(unknown[flag] - 'A');
			flag++;
		}
		min.push_back(temp);
	}
	flag = 0;
	for (int i = 0; i < 3; i++) {
		vector<int> temp;
		for (int j = 0; j < 3; j++) {
			temp.push_back(known[flag] - 'a');
			flag++;
		}
		mi.push_back(temp);
	}
	ans = mult(mi, ans);
	vector<int> fin;
	for (int i = 0; i < 3; i++) {
		fin.push_back(min[1][i] - ans[1][i]);
	}
	cout << "ƫ�ƾ���\n";
	for (int i = 0; i < 3; i++) {
		cout << (fin[i] % 26 +26)%26<< " ";
	}
}

