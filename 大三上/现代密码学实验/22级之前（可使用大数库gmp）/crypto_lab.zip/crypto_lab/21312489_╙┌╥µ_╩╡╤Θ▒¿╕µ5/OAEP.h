#pragma once
#include <iostream>
#include <random>
#include <sstream>
#include <iomanip>
#include "SHA256.h"
using namespace std;

string xor_0x(string a, string b);//�ַ������
string en_OAEP(string m, string r);// ���
string de_OAEP(string s);// ������
string OAEP(string a);// OAEP ���
string hex2bits(string addstr_1,int step);//hex->bits
string bits2hex(string binary_str);//bits->hex

string xor_0x(string addstr_1, string addstr_2) {
	bitset<1024> a1(hex2bits(addstr_1,2));
	bitset<1024> b1(hex2bits(addstr_2,2));
	return bits2hex((a1 ^ b1).to_string());
}

string en_OAEP(string m, string r) {
	string temp1 = Sha256(r + "00000000", init_hash_value) + Sha256(r + "00000001", init_hash_value) + Sha256(r + "00000002", init_hash_value) + Sha256(r + "00000003", init_hash_value);
	temp1[0] = '0'; temp1[1] = '0'; temp1[2] = '0'; temp1[3] = '0';

	string str_1 = xor_0x(m, temp1);

	string str_2 = Sha256(str_1 + "00000000", init_hash_value) + Sha256(str_1 + "00000001", init_hash_value) + Sha256(str_1 + "00000002", init_hash_value) + Sha256(str_1 + "00000003", init_hash_value);
	str_2[0] = '0'; str_2[1] = '0'; str_2[2] = '0'; str_2[3] = '0';

	return xor_0x(m, temp1)+ xor_0x(r, str_2);
}

string de_OAEP(string a) {
	string s = "0000";
	s += a;

	string half_1 = s.substr(0, 256);
	string half_2 = s.substr(256,256);

	string h = Sha256(half_1 + "00000000", init_hash_value) + Sha256(half_1 + "00000001", init_hash_value) + Sha256(half_1 + "00000002", init_hash_value) + Sha256(half_1 + "00000003", init_hash_value);
	h[0] = '0'; h[1] = '0'; h[2] = '0'; h[3] = '0';

	string r = xor_0x(half_2, h);
	string g = Sha256(r + "00000000", init_hash_value) + Sha256(r + "00000001", init_hash_value) + Sha256(r + "00000002", init_hash_value) + Sha256(r + "00000003", init_hash_value);
	g[0] = '0'; g[1] = '0'; g[2] = '0'; g[3] = '0';

	string ans;
	for (int i = 0; i < 256 - 1; i += 2)
		if (xor_0x(half_1, g).substr(i, 2)!= "00") ans += xor_0x(half_1, g).substr(i, 2);
	return ans;
}

string OAEP(string a) {
	random_device rd;mt19937 gen(rd());
	uniform_int_distribution<int> distribution(0, 15); std::string hexString; hexString.reserve(256); 
	for (int i = 0; i <256 ; ++i) { int randomDigit = distribution(gen); 
	if (randomDigit < 10)hexString += std::to_string(randomDigit);
	else hexString += char(randomDigit - 10 + int('a'));
	}
	string r = hexString;
	string OAEPed_str;
	std::ostringstream ascii;
	for (auto c : a) ascii << setw(2) << setfill('0') << hex << static_cast<int>(c);
	for (int i = 0; i < (256 - ascii.str().length()); i++)OAEPed_str += "0";
	OAEPed_str += ascii.str();
	OAEPed_str = en_OAEP(OAEPed_str, r);
	return OAEPed_str;
}

string hex2bits(string addstr_1,int step) {
	string s1;
	for (int i = 0; i < addstr_1.length(); i += step) {
		std::string part = addstr_1.substr(i, step);
		std::stringstream ss;
		ss << hex << part;
		unsigned n;
		ss >> n;
		std::bitset<8> bitset(n);
		s1 += bitset.to_string();
	}
	return s1;
}
string bits2hex(string binary_str) {
	string ans;
	for (int i = 0; i < binary_str.length(); i += 8) {
		std::string part = binary_str.substr(i, 8);
		std::bitset<8> bitset(part);
		std::stringstream ss;
		ss << setw(2) << setfill('0') << std::hex << bitset.to_ulong();
		ans += ss.str();
	}
	return ans;
}