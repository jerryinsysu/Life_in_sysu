#include <iostream>
#include <gmpxx.h>
#include "OAEP.h"
using namespace std;

int main() {
	mpz_t num_ID;
	mpz_t prime_ID;
	mpz_init(num_ID);
	mpz_init(prime_ID);
	// �ҵ�ѧ����һ������
	mpz_set_str(num_ID, "21312489", 10);
	mpz_nextprime(prime_ID, num_ID);

	//��ʼ�����ø�������(������Կ)
	mpz_class p("100844248375667960531515427692725905394401478603610733523704989459859859834224729368913031314613271713854424296064226436067135342839462150964333068225460133995631125405416898437220598917294877099133441588354697918306389699212343197841022961176669093814001144951874594795432849758596534589993467741921347017087");
	mpz_class q("100526852643125554670585450928284888310671324742526520510127287156401626914626520287883943999051147408548248473543661858872651666689644265808937518825306129003238255005956537741509275434459174468223658404078664815145058048695108147571851282122621450237053865995121546114021141074773915652613675133521966934067");
	mpz_class n = p * q;
	mpz_class phi_n = (p - 1) * (q - 1);// \phi(n)=\phi(p)*\phi(q)=(p-1)*(q-1)
	mpz_class d(prime_ID);
	mpz_class e;
	mpz_invert(e.get_mpz_t(), d.get_mpz_t(), phi_n.get_mpz_t());//ȡmod(\phi(n))�µ���Ԫ
	
	//����e*d%\phi(n)���
	mpz_t r;
	mpz_init(r);
	mpz_class ed = e * d;
	mpz_mod(r, ed.get_mpz_t(),phi_n.get_mpz_t());
	gmp_printf("����e*dģphi(n)�����\ne*d(mod phi(n))=%Zd\n",r);

	cout << "����չʾ:   " << '\n';
	cout << "p:\n  " << p << '\n';
	cout << "q:\n  " << q << '\n';
	cout << "n:\n  " << n << '\n';
	cout << "d:\n  " << d << '\n';
	cout << "e:\n  " << e << '\n';

	//��Ϣ���
	string message = OAEP("yuyi");
	mpz_class m("0x"+message);
	cout << "�������m=\n  " << m << '\n';

	//����m^e=c (modn)
	mpz_class cc;
	mpz_class c;
	mpz_powm(cc.get_mpz_t(), m.get_mpz_t(), e.get_mpz_t(), n.get_mpz_t());
	mpz_mod(c.get_mpz_t(),cc.get_mpz_t(), n.get_mpz_t());
	cout << "��Կ(n,e)���ܽ����c=\n  0x" << hex <<c << '\n';

	//����c^d=m (modn)
	mpz_class decryed_m;
	mpz_powm(decryed_m.get_mpz_t(), c.get_mpz_t(), d.get_mpz_t(), n.get_mpz_t());
	cout << "˽Կ(n,d)���ܽ����=\n  0x" << hex << decryed_m;
	cout << "\n�Աȼ��ܺ�ԭ��(�Ƿ���ͬ)�� " << std::boolalpha<<!bool(mpz_cmp(decryed_m.get_mpz_t(), m.get_mpz_t()));
	
	string temp = mpz_get_str(nullptr, 16, m.get_mpz_t());

	std::string resultString;
	for (size_t i = 0; i < de_OAEP(temp).length(); i += 2)
		resultString.push_back(static_cast<char>(std::stoi(de_OAEP(temp).substr(i, 2), nullptr, 16)));

	cout << "\n�ֽڽ������:  " << resultString;

	return 0;
}


