#include<gmpxx.h> 
#include"tools.h"
using namespace std;
//pollard������������PPTα����
mpz_class  Pollard(mpz_class A, mpz_class B, mpz_class n, mpz_class p) {
	mpz_class x = 1, a = 0, b = 0;
	mpz_class x_pai = 1, a_pai = 0, b_pai = 0;
	f(x, a, b, A, B, n, p);
	f(x_pai, a_pai, b_pai, A, B, n, p);
	f(x_pai, a_pai, b_pai, A, B, n, p);
	for (;x != x_pai;) {
		f(x, a, b, A, B, n, p);
		f(x_pai, a_pai, b_pai, A, B, n, p);
		f(x_pai, a_pai, b_pai, A, B, n, p);
	}
	mpz_class temp_zero = 0;
	mpz_class ans = 0;
	mpz_class temp1 = liEu(((b_pai - b) % n + n) % n, n, ((a - a_pai) % n + n) % n, ans, temp_zero);
	mpz_class temp2 = n / temp1;
	ans = (ans % temp2 + temp2) % temp2;
	for (mpz_class i = 1; i < temp1; i++) {
		mpz_class temp;
		mpz_powm(temp.get_mpz_t(), A.get_mpz_t(), ans.get_mpz_t(), p.get_mpz_t());
		if (temp == B) break;
		else ans += i * temp2;
	}
	return ans;
}

int main() {
	//����1��p = 809, g = 89, y = 618, x = 49
	mpz_class p("809");
	mpz_class g("89");
	mpz_class y("618");
	mpz_class n= calculate_order_n(p, g);
	cout << "<---test1--->\ng:"<<g<<"\n";
	cout << "y:" << y << '\n';
	cout << "p:" << p << '\n';
	cout << "n(order):" << n << '\n';
	mpz_class ans = Pollard(g, y, n, p);
	cout << "x:" << ans<<'\n';

	//����2��p = 5041259, g = 2, y = 424242, x = 5142
	mpz_class p1("5041259");
	mpz_class g1("2");
	mpz_class y1("424242");
	mpz_class n1= calculate_order_n(p1, g1);
	cout << "<---test2--->\ng:" << g1 << "\n";
	cout << "y:" << y1 << '\n';
	cout << "p:" << p1 << '\n';
	cout << "n(order):" << n1 << '\n';
	mpz_class ans1 = Pollard(g1, y1, n1, p1);
	cout << "x:" << ans1 << '\n';

	////ѧ�ż���,sympy ��֤���Ϊ2389143335945788826
	mpz_class p2("31050371851708889440695779044384182719244728783");
	mpz_class g0 = 5;
	mpz_class gg("1208925819614629174706189");
	mpz_class num("21312489");
	mpz_class g2 = gg * 2 * 1097 * num;
	mpz_powm(g2.get_mpz_t(), g0.get_mpz_t(), g2.get_mpz_t(), p2.get_mpz_t());
	mpz_class y2("13821904325547285207847180361637528630753679004");
	mpz_class n2("11706593258111142827");
	cout << "<---test3--->\ng:" << g2 << "\n";
	cout << "y:" << y2 << '\n';
	cout << "p:" << p2 << '\n';
	cout << "n(order):" << n2 << '\n';
	mpz_class ans2 = Pollard(g2, y2, n2, p2);
	cout << "x:" << ans2 << '\n';

	return 0;
}
