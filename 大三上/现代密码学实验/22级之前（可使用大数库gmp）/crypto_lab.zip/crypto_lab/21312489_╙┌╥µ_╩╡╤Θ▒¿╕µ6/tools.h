#pragma once
#include<iostream>
#include<gmpxx.h>
#include<vector>
using namespace std;

vector<mpz_class> factors_list(mpz_class n);// ��ȡ�����б�
mpz_class calculate_order_n(mpz_class p, mpz_class a);// ��order
void f(mpz_class& x, mpz_class& a, mpz_class& b, mpz_class A, mpz_class B, mpz_class n, mpz_class p);//producer f()
mpz_class liEu(mpz_class a, mpz_class b, mpz_class c, mpz_class& x, mpz_class& y);//�����Է��̣��ο�PPT�������ӵĺ���
mpz_class ex_gcd(mpz_class a, mpz_class b, mpz_class& x, mpz_class& y);//�ο�PPT�������ӵĺ���,��չŷ������㷨

vector<mpz_class> factors_list(mpz_class n) {
	vector<mpz_class> factor_lis;
	for (mpz_class i = 2; n >= i * i ; ++i) 
		for(;n%i==0;n/=i)
			factor_lis.push_back(i);
	if (n > 1) 
		factor_lis.push_back(n);
	return factor_lis;
}

mpz_class calculate_order_n(mpz_class p, mpz_class a) {
	mpz_class order = p - 1;
	vector<mpz_class> factorss = factors_list(order);
	for (auto i : factorss) {
		mpz_class temp = order / i;
		mpz_powm(temp.get_mpz_t(), a.get_mpz_t(), temp.get_mpz_t(), p.get_mpz_t()); // a^mid % p
		if (temp == 1)
			order /= i;
	}
	return order;
}
void f(mpz_class& x, mpz_class& a, mpz_class& b, mpz_class A, mpz_class B, mpz_class n, mpz_class p) {

	if (x % 3 == 0) 
		x = (x * x) % p,a = (2 * a) % n,b = (2 * b) % n;
	else if (x % 3 == 1) 
		x = (B * x) % p,b = (b + 1) % n;
	else if (x % 3 == 2)
		x = (A * x) % p,a = (1 + a) % n;
}

mpz_class ex_gcd(mpz_class a, mpz_class b, mpz_class& x, mpz_class& y) {
	if (b == 0) {
		x = 1, y = 0;
		return a;
	}
	mpz_class d = ex_gcd(b, a % b, x, y);
	mpz_class temp = x;
	x = y;
	y = temp - a / b * y;
	return d;
}

mpz_class liEu(mpz_class a, mpz_class b, mpz_class c, mpz_class& x, mpz_class& y) {
	mpz_class d = ex_gcd(a, b, x, y); 
	if (c % d != 0) return 0;
	mpz_class k = c / d;
	x *= k;
	y *= k;
	return d;
}
