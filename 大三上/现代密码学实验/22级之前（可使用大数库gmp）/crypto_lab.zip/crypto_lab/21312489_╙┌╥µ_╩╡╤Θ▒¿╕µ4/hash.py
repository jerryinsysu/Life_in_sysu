import hmac
import hashlib

# 设置HMAC密钥
key = b'21305181'  # 将密钥替换为您自己的密钥
# for i in range(4):
#     key+=key
_key=b'21305181'
for i in range(4):
    _key+=_key
# 创建SHA-256哈希对象
hm = hmac.new(key,digestmod='sha256') #创建h2对象时先传入部分内容

# 打开大文件并按块处理
file_path = "C:\\Users\\yuyi\\Downloads\\ubuntu-22.04.3-desktop-amd64.iso" #替换为实际文件路径
block_size = 4096  # 块大小（可以根据需要调整）

with open(file_path, 'rb') as file:
    while True:
        data = file.read(block_size)
        if not data:
            break
        hm.update(bytes(data))

# 打印HMAC哈希值
print("HMAC SHA-256 for the file:", hm.digest().hex())
