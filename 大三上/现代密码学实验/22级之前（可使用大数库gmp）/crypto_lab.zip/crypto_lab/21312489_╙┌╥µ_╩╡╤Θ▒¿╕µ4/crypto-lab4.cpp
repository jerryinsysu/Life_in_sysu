#include <iostream>
#include <bitset>
#include "crypto-lab4.h"

using namespace std;

int main() {
	string path = "D:/software/΢���ļ�/WeChat Files/wxid_6paxlg4lea0a22/FileStorage/File/2023-11/Firefox Setup 118.0 (1).msi";
	
	string s = "cdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcd";
	string k = "0102030405060708090a0b0c0d0e0f10111213141516171819";
	cout << "HMAC ��֤��վ����4.5" << endl;
	vector<bitset<32> >  result = hmac(k,s,init_hash_value);
	result_output(result, "HMAC-Sha256 =   ");

	s = "7768617420646f2079612077616e7420666f72206e6f7468696e673f";
	k = "4a656665";
	cout << "HMAC ��֤��վ����4.3" << endl;
	result = hmac(k, s, init_hash_value);
	result_output(result, "HMAC-Sha256 =   ");
	
	cout << "firefox����sha256:" << endl;
	auto a = block_sha256(path);
	result_output(a,"SHA256=  ");

	path = "C:\\Users\\yuyi\\Downloads\\ubuntu-22.04.3-desktop-amd64.iso";
	cout << "ubuntu22.0 ����sha256:" << endl;
	a = block_sha256(path);
	result_output(a, "SHA256=  ");
	
	string k1 = "5049514950525657";//xuehao:21312489
	cout << "Key = " << k1 << endl;
	result = block_hmac(k1, path, init_hash_value);
	result_output(result, "HMAC=  ");

	//16��
	 k1 = "5049514950525657";//xuehao:21312489
		for (long long int i = 0; i < 4; i++) k1 += k1;
			cout << "Key = "<< k1 << endl; 
		result = block_hmac(k1, path, init_hash_value);
		result_output(result, "HMAC=  ");
	return 0;
}