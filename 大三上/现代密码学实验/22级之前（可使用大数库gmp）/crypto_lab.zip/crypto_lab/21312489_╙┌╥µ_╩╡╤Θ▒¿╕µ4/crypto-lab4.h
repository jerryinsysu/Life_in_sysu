#pragma once
#include <iostream>
#include <bitset>
#include <string>
#include <vector>
#include <sstream>
#include <iomanip>
#include <fstream>
#include <cmath>

using namespace std;
vector<bitset<32>> block_sha256(string , string );// SHA-256 �鴦������
vector<bitset<32> > block_hmac(string k, string m_path, vector<string>& hs);// HMAC �鴦������
void result_output(vector<bitset<32>>& ans, string s);
vector<bitset<32>> Sha256(string s, vector<string>& hs);//SHA256����
string padding(string s, long int n);//���
//ѹ������
bitset<32> compress_1(bitset<32>& e, bitset<32>& f, bitset<32>& g, bitset<32>& h, vector<bitset<32>>& w1, vector<bitset<32>>& k1, int i);
bitset<32> compress_2(bitset<32>& a, bitset<32>& b, bitset<32>& c);
vector<bitset<32>> H(vector<bitset<32>>& w1, vector<bitset<32>>& k1, vector<bitset<32>>& h1);

vector<bitset<8>> sttring_2_8bits(string s);// ��Ϊ8λ�����ƿ�ĺ���
vector<bitset<32>> bits2_32bit(vector<bitset<8>>& a);// ת��Ϊ32λ�ֵĺ���

string bits32_2_string(vector<bitset<32>>& b);
vector<bitset<32>> hmac(string k, string m, vector<string>& hs);
bitset<32> o0(vector<bitset<32>>& w, int i);// o0����
bitset<32> o1(vector<bitset<32>>& w, int i);// o1����
vector<bitset<32>> message_padding(vector<bitset<32>>& ans);// ��Ϣ��չ

// ��ʼ��ϣֵ�ĳ���
vector<string> init_hash_value =
{
	"01101010000010011110011001100111",
	"10111011011001111010111010000101",
	"00111100011011101111001101110010",
	"10100101010011111111010100111010",
	"01010001000011100101001001111111",
	"10011011000001010110100010001100",
	"00011111100000111101100110101011",
	"01011011111000001100110100011001"
};

// ����
string hash_constant[64] =
{
	"01000010100010100010111110011000","01110001001101110100010010010001",
	"10110101110000001111101111001111","11101001101101011101101110100101",
	"00111001010101101100001001011011","01011001111100010001000111110001",
	"10010010001111111000001010100100","10101011000111000101111011010101",
	"11011000000001111010101010011000","00010010100000110101101100000001",
	"00100100001100011000010110111110","01010101000011000111110111000011",
	"01110010101111100101110101110100","10000000110111101011000111111110",
	"10011011110111000000011010100111","11000001100110111111000101110100",
	"11100100100110110110100111000001","11101111101111100100011110000110",
	"00001111110000011001110111000110","00100100000011001010000111001100",
	"00101101111010010010110001101111","01001010011101001000010010101010",
	"01011100101100001010100111011100","01110110111110011000100011011010",
	"10011000001111100101000101010010","10101000001100011100011001101101",
	"10110000000000110010011111001000","10111111010110010111111111000111",
	"11000110111000000000101111110011","11010101101001111001000101000111",
	"00000110110010100110001101010001","00010100001010010010100101100111",
	"00100111101101110000101010000101","00101110000110110010000100111000",
	"01001101001011000110110111111100","01010011001110000000110100010011",
	"01100101000010100111001101010100","01110110011010100000101010111011",
	"10000001110000101100100100101110","10010010011100100010110010000101",
	"10100010101111111110100010100001","10101000000110100110011001001011",
	"11000010010010111000101101110000","11000111011011000101000110100011",
	"11010001100100101110100000011001","11010110100110010000011000100100",
	"11110100000011100011010110000101","00010000011010101010000001110000",
	"00011001101001001100000100010110","00011110001101110110110000001000",
	"00100111010010000111011101001100","00110100101100001011110010110101",
	"00111001000111000000110010110011","01001110110110001010101001001010",
	"01011011100111001100101001001111","01101000001011100110111111110011",
	"01110100100011111000001011101110","01111000101001010110001101101111",
	"10000100110010000111100000010100","10001100110001110000001000001000",
	"10010000101111101111111111111010","10100100010100000110110011101011",
	"10111110111110011010001111110111","11000110011100010111100011110010"
};


string padding(string s, long int n) 
{
	s += "8";  // ����'1'λ��'0'λ
	s += '0';
	long int counter = 0;
	long int _counter = n + 2;
	if ((_counter < 112) || ((_counter - 112) % 128 != 0)) 
		for (int i = 0; i < ((112 + 128) - (_counter % 128)) % 128 / 2; i++)
			s += "00";  // ����0���
	_counter = n * 4 / 256;
	while (_counter) 
		counter++,_counter /= 256;

	for (int i = 0; i < (8 - counter) - 1; i++) s += "00";  // ���뵽8�ֽ�

	long int n__ = pow(256, counter);
	long int n_2 = n * 4;
	while (n__ != 0) 
	{
		long int n2 = (n_2 / n__);
		stringstream ss;
		ss << setfill('0') << setw(2) << hex << n2;
		s += ss.str();
		n_2 %= n__;
		n__ /= 256;
	}
	return s;
}


vector<bitset<8>> sttring_2_8bits(string s) 
{
	vector<bitset<8>> ans;
	for (int i = 0; i < s.length(); i += 2) 
	{
		bitset<8> temp(stoi(s.substr(i, 2), 0, 16));
		ans.push_back(temp);
	}
	return ans;
}


vector<bitset<32>> bits2_32bit(vector<bitset<8>>& a) 
{
	vector<bitset<32>> ans;
	for (int i = 1; i <= a.size(); i += 4)
	{
		bitset<32> _ans;
		int j = 0;
		while (j < 8)
		{
			_ans[3 * 8 + j] = a[i - 1][j];
			_ans[2 * 8 + j] = a[i][j];
			_ans[1 * 8 + j] = a[i + 1][j];
			_ans[0 * 8 + j] = a[i + 2][j];
			j++;
		}
		ans.push_back(_ans);
	}
	return ans;
}


bitset<32> o0(vector<bitset<32>>& w, int i) {
	int count=0;
	count = 7;
	bitset<32> temp1 = w[i] >> count | w[i] << (32 - count);
	count = 18;
	bitset<32> temp_value2 = w[i] >> count | w[i] << (32 - count);
	bitset<32> temp_value3 = w[i] >> 3;
	bitset<32> ans = temp1 ^ temp_value2 ^ temp_value3;
	return ans;
}

bitset<32> o1(vector<bitset<32>>& w, int i) {
	int count = 17;
	bitset<32> temp_value1 = w[i] >> count | w[i] << (32 - count);
	count = 19;
	bitset<32> temp_value2 = w[i] >> count | w[i] << (32 - count);
	bitset<32> temp_value3 = w[i] >> 10;
	bitset<32> ans = temp_value1 ^ temp_value2 ^ temp_value3;
	return ans;
}

vector<bitset<32>> message_padding(vector<bitset<32>>& ans) {
	for (int i = 16; i < 64; i++) {
		bitset<32> a = ans[i - 16];
		bitset<32> b = o0(ans, i - 15);
		bitset<32> c = ans[i - 7];
		bitset<32> d = o1(ans, i - 2);
		bitset<32> temp_value(a.to_ulong() + b.to_ulong() + c.to_ulong() + d.to_ulong());
		ans.push_back(temp_value);
	}
	return ans;
}

// ѹ������
bitset<32> compress_1(bitset<32>& e, bitset<32>& f, bitset<32>& g, bitset<32>& h, vector<bitset<32>>& w1, vector<bitset<32>>& k1, int i) {
	bitset<32> sum1 = (e >> 6 | e << (32 - 6)) ^ (e >> 11 | e << (32 - 11)) ^ (e >> 25 | e << (32 - 25));
	bitset<32> e_ = e.flip();
	e.flip();
	auto ef = (e & f);
	auto e_g = (e_ & g);
	auto answer = h.to_ulong() + sum1.to_ulong() + (ef ^ e_g).to_ulong() + k1[i].to_ulong() + w1[i].to_ulong();
	bitset<32> ans(answer);
	return ans;
}

// ѹ������
bitset<32> compress_2(bitset<32>& a, bitset<32>& b, bitset<32>& c)
{
	bitset<32> ss = (a >> 2 | a << (32 - 2)) ^ (a >> 13 | a << (32 - 13)) ^ (a >> 22 | a << (32 - 22));
	auto ab = a & b;
	auto ac = (a & c);
	auto bc = (b & c);
	bitset<32> ans(ss.to_ulong() + ((ab) ^ (ac) ^ (bc)).to_ulong());
	return ans;
}

// ѹ������--H
vector<bitset<32>> H(vector<bitset<32>>& w1, vector<bitset<32>>& k1, vector<bitset<32>>& h1) 
{
	
	vector<bitset<32> > as;
	for (auto i = 0; i < 8; i++)
	{
		as.push_back(h1[i]);
	}

	bitset<32> a = h1[0];
	bitset<32> b = h1[1];
	bitset<32> c = h1[2];
	bitset<32> d = h1[3];
	bitset<32> e = h1[4];
	bitset<32> f = h1[5];
	bitset<32> g = h1[6];
	bitset<32> h = h1[7];
	for (int i = 0; i < 64; i++) 
	{
		bitset<32> Temp1 = compress_1(e, f, g, h, w1, k1, i);
		bitset<32> Temp2 = compress_2(a, b, c);
		h = g;
		g = f;
		f = e;
		bitset<32> temp_value(d.to_ulong() + Temp1.to_ulong());
		e = temp_value;
		d = c;
		c = b;
		b = a;
		bitset<32> temp_value1(Temp1.to_ulong() + Temp2.to_ulong());
		a = temp_value1;
	}

	bitset<32> temp_valuea(a.to_ulong() + h1[0].to_ulong());
	bitset<32> temp_valueb(b.to_ulong() + h1[1].to_ulong());
	bitset<32> temp_valuec(c.to_ulong() + h1[2].to_ulong());
	bitset<32> temp_valued(d.to_ulong() + h1[3].to_ulong());
	bitset<32> temp_valuee(e.to_ulong() + h1[4].to_ulong());
	bitset<32> temp_valuef(f.to_ulong() + h1[5].to_ulong());
	bitset<32> temp_valueg(g.to_ulong() + h1[6].to_ulong());
	bitset<32> temp_valueh(h.to_ulong() + h1[7].to_ulong());

	vector<bitset<32> > temp_value;
	temp_value.push_back(temp_valuea);
	temp_value.push_back(temp_valueb);
	temp_value.push_back(temp_valuec);
	temp_value.push_back(temp_valued);
	temp_value.push_back(temp_valuee);
	temp_value.push_back(temp_valuef);
	temp_value.push_back(temp_valueg);
	temp_value.push_back(temp_valueh);

	vector<bitset<32>> result;
	for (auto i = 0; i < temp_value.size(); i++)
		result.push_back(temp_value[i]);
	return result;
}

// ���
void result_output(vector<bitset<32>>& ans, string s) 
{
	// ��ӡ���
	cout << s;
	for (int j = 0; j < 8; j++) 
	{
		for (int i1 = 0; i1 < 4; i1++) 
		{
			bitset<8> temp_value(ans[j].to_string().substr(i1 * 8, 8));
			cout << hex << temp_value.to_ulong();
		}
	}
	cout << endl;
}

// SHA-256 
vector<bitset<32>> Sha256(string s, vector<string>& hs) 
{
	vector<bitset<32>> h;
	vector<bitset<8>> w1 = sttring_2_8bits(s);
	vector<bitset<32>> w0 = bits2_32bit(w1);
	for (int i = 0; i < hs.size(); i++) {
		bitset<32> temp_value(hs[i]); h.push_back(temp_value);
	}
	vector<bitset<32>> k;
	for (int i = 0; i < (sizeof(hash_constant) / sizeof(hash_constant[0])); i++) 
	{
		bitset<32> temp_value(hash_constant[i]); k.push_back(temp_value);
	}
	vector<vector<bitset<32>>> w;
	for (int i = 0; i < (w0.size() / 16); i++) 
	{
		vector<bitset<32>> temp_value;
		for (int j = 0; j < 16; j++) 
			temp_value.push_back(w0[i * 16 + j]);
		w.push_back(temp_value);
	}
	vector<bitset<32>> result;
	for (int i = 0; i < w.size(); i++) 
	{
		vector<bitset<32>> temp_value = w[i];
		temp_value = message_padding(temp_value);
		h = H(temp_value, k, h);
		result = h;
	}
	return result;
}

string bits32_2_string(vector<bitset<32>>& b) 
{
	string result;
	vector<bitset<32>> a(b);
	for (int i = 0; i < a.size(); i++) 
	{
		for (int j = 0; j < 4; j++) 
		{
			bitset<8> part(a[i].to_string().substr(j * 8, 8)); // ��ԭbitset�н�ȡ8λ
			int asciiValue = part.to_ulong(); // ת��Ϊʮ��������
			stringstream ss;
			ss << hex << setfill('0') << setw(2) << asciiValue; // ת��Ϊ16�����ַ���
			result += ss.str(); // ���ӵ�����ַ���
		}
	}
	return result;
}

vector<bitset<32>> hmac(string k, string m, vector<string>& hs) 
{
	vector<bitset<8>> k_block;
	vector<bitset<32>> k1;
	for (int i = 0; i < k.length(); i += 2) 
	{
		bitset<8> temp_value(stoi(k.substr(i, 2), 0, 16));
		k_block.push_back(temp_value);
	}
	bitset<8> temp_value;
	if (k_block.size() > 64) k1 = Sha256(padding(k, k.length()), hs);
	while (k_block.size() < 64) k_block.push_back(temp_value);
	k1 = bits2_32bit(k_block);
	vector<bitset<32>> opad;
	vector<bitset<32>> ipad;
	for (int i = 0; i < 16; i++) {
		bitset<32> temp_value_opad(0x5C5C5C5C);
		opad.push_back(temp_value_opad);
		bitset<32> temp_value_ipad(0x36363636);
		ipad.push_back(temp_value_ipad);
	}
	vector<bitset<32>> kopad;
	for (int i = 0; i < 16; i++) kopad.push_back(k1[i] ^ opad[i]);
	vector<bitset<32>> kipad;
	for (int i = 0; i < 16; i++) kipad.push_back(k1[i] ^ ipad[i]);
	string ipads = bits32_2_string(kipad);
	ipads += m;
	ipads = padding(ipads, ipads.length());
	vector<bitset<32>> hash1 = Sha256(ipads, hs);
	for (int i = 0; i < hash1.size(); i++) kopad.push_back(hash1[i]);
	string opads = bits32_2_string(kopad);
	opads = padding(opads, opads.length());
	vector<bitset<32>> hash2 = Sha256(opads, hs);
	return hash2;
}

vector<bitset<32>> block_sha256(string ossssss, string filePath) {
	vector<bitset<32>> ans;
	vector<string> h = init_hash_value;
	ifstream inputFile(filePath, ios::binary);
	int x = 1;
	long int counter = 0;
	ostringstream out_str;
	out_str << hex << setfill('0');
	for (int i = 0; i < ossssss.length(); i++,counter++,x++) out_str << int(ossssss[i] - '0');
	counter /= 2;
	char c;
	while (inputFile.get(c)) 
	{
		counter++;
		out_str << setw(2) << static_cast<int>(static_cast<unsigned char>(c));
		if (x != 640000) x++;
		else 
		{
			ans = Sha256(out_str.str(), h);
			for (int i = 0; i < ans.size(); i++) h.push_back(ans[i].to_string());
			x = 1;
			out_str.str("");
		}
	}
	ans = Sha256(padding(out_str.str(), counter * 2), h);
	inputFile.close();
	return ans;
}

vector<bitset<32> > block_hmac(string k, string main_p, vector<string>& hs) {
	vector<bitset<8> > k_block;
	vector<bitset<32> > k1;
	for (int i = 0; i < k.length(); i += 2) 
	{
		bitset<8> temp_value(stoi(k.substr(i, 2), 0, 16));
		k_block.push_back(temp_value);
	}
	bitset<8> temp_value;
	if (k_block.size() > 64) k1 = Sha256(padding(k, k.length()), hs);
	while (k_block.size() < 64) k_block.push_back(temp_value);
	k1 = bits2_32bit(k_block);
	vector<bitset<32> > opad;
	vector<bitset<32> > ipad;
	for (int i = 0; i < 16; i++) 
	{
		bitset<32> temp_value_opad(0x5C5C5C5C);
		opad.push_back(temp_value_opad);
		bitset<32> temp_value_ipad(0x36363636);
		ipad.push_back(temp_value_ipad);
	}
	vector<bitset<32> > kopad;
	for (int i = 0; i < 16; i++) kopad.push_back(k1[i] ^ opad[i]);
	vector<bitset<32> > kipad;
	for (int i = 0; i < 16; i++) kipad.push_back(k1[i] ^ ipad[i]);
	vector<bitset<32> > hash1 = block_sha256(bits32_2_string(kipad), main_p);
	for (int i = 0; i < hash1.size(); i++)	kopad.push_back(hash1[i]);
	string opads = padding(bits32_2_string(kopad), bits32_2_string(kopad).length());
	vector<bitset<32> > hash2 = Sha256(opads, hs);
	return hash2;
}

vector<bitset<32>> block_sha256(string filePath) {
	return block_sha256("", filePath);
}