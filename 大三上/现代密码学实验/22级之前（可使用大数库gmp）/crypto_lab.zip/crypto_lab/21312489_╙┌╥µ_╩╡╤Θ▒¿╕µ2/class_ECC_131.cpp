#include <iostream>
#include <bitset>
#include <vector>
#include <algorithm>
#include <numeric>
#include "class_ECC_131.h"
#define SIZE 131
#define ll long long
using namespace std;

string ID = "100001001100010010010010001001";//�ҵ�ѧ�ţ�21312489����Ϊ16����ת��Ϊ2���ƽ��
bitset<2 * SIZE> ID_set(ID);

//���͵ķǵݹ������
template <typename T>
T qpow(T a, ll n)
{
	T ans(bitset<2*SIZE>("01")); // ��ֵΪ�˷���λԪ
	while (n)
	{
		if (n & 1)
			ans = ans * a; // �������Գˣ���Ȼ������*��Ҫ����*=
		n >>= 1;
		a = a * a;
	}
	return ans;
}

uint64_t now() {
	struct timespec t;
	timespec_get(&t, TIME_UTC);
	return (uint64_t)1e9 * t.tv_sec + t.tv_nsec;
}

void timecos(double average, double upfour, double downfour, double middle, string name)
{
	cout << name << "����ʱ��:" << endl;
	cout << "ƽ��ʱ��:" << average << endl;
	cout << "���ķ�λ��:" << upfour << endl;
	cout << "��λ��:" << middle << endl;
	cout << "���ķ�λ��:" << downfour << endl;
	cout << endl;
}


int main() {
	ECC_131 my_ID(ID_set);
	bitset<2 * SIZE> test_bits;
	test_bits[2] = 1;
	test_bits[0] = 1;
	test_bits[13] = 1;
	ECC_131 test(test_bits);
	printf(">>>>>��֤������ȷ��,�� a= x^13 + x^2 + 1Ϊ����");
	cout << "a:\t" << test << endl;
	cout << "a^2:\t" << test.square() << endl;
	cout << "a^-1(��չŷ�����):\t" << test.inverse() << endl;
	cout << "a^-1(����):\t" << test.inverse_2() << endl;
	cout << "a^-1+a:\t" << test.inverse() + test << endl;
	ll counter = 114514;
	cout << "a^"<<counter<<": \t" << qpow(test, counter) << endl;
	
	cout << ">>>>>";
	cout << "�ҵ�ѧ��ID:21312489,ת���ɶ����ƴ�s_ID:" << my_ID;
	cout << "s_ID^-1:\t" << my_ID.inverse() << endl;
	cout << "s_ID+s_ID^-1:\t" << my_ID.inverse() + my_ID << endl;
	counter = 19260817;
	cout << "s_ID^19260817��\t" << qpow(my_ID, counter);

	cout << ">>>>>���������ʱ��(100000��)��" << endl;
	double average;
	vector<uint64_t>timevec;
	
	for (int j = 0; j < 100; j++) {
		ECC_131 q(ID_set);
		uint64_t ts = now();
		for (int i = 0; i < 1000; i++) {
			q + q;
		}
		uint64_t te = now();
		timevec.push_back((te - ts) );
	}
	sort(timevec.begin(), timevec.end());
	average = accumulate(begin(timevec), end(timevec), 0.0) / timevec.size();
	timecos(average, timevec[24], timevec[74], timevec[49], "��/����");

	timevec.clear();
	average = 0;
	for (int j = 0; j < 100; j++) {
		ECC_131 q(ID_set);
		uint64_t ts = now();
		for (int i = 0; i < 1000; i++) {
			q * q;
		}
		uint64_t te = now();
		timevec.push_back((te - ts) );
	}
	sort(timevec.begin(), timevec.end());
	average = accumulate(begin(timevec), end(timevec), 0.0) / timevec.size();
	timecos(average, timevec[24], timevec[74], timevec[49], "�˷�");

	timevec.clear();
	average = 0;
	for (int j = 0; j < 100; j++) {
		ECC_131 q(ID_set);
		uint64_t ts = now();
		for (int i = 0; i < 1000; i++) {
			q.square();
		}
		uint64_t te = now();
		timevec.push_back((te - ts) );
	}
	sort(timevec.begin(), timevec.end());
	average = accumulate(begin(timevec), end(timevec), 0.0) / timevec.size();
	timecos(average, timevec[24], timevec[74], timevec[49], "ƽ��");

	timevec.clear();
	average = 0;
	for (int j = 0; j < 100; j++)
	{
		ECC_131 q(ID_set);
		uint64_t ts = now();
		for (int i = 0; i < 1000; i++)
		{
			q.inverse();
		}
		uint64_t te = now();
		timevec.push_back((te - ts) );
	}
	sort(timevec.begin(), timevec.end());
	average = accumulate(begin(timevec), end(timevec), 0.0) / timevec.size();
	timecos(average, timevec[24], timevec[74], timevec[49], "��չŷ���������");

	timevec.clear();
	average = 0;
	for (int j = 0; j < 100; j++)
	{
		ECC_131 q(ID_set);
		uint64_t ts = now();
		for (int i = 0; i < 1000; i++)
		{
			q.inverse_2();
		}
		uint64_t te = now();
		timevec.push_back((te - ts) );
	}
	sort(timevec.begin(), timevec.end());
	average = accumulate(begin(timevec), end(timevec), 0.0) / timevec.size();
	timecos(average, timevec[24], timevec[74], timevec[49], "����С��������");
	
	return 0;
}