#include<iostream>
#include<bitset>
#define SIZE 131
#define ll long long
using namespace std;

int get_index(bitset<2 * SIZE>& a) {
    for (int i = 2 * SIZE - 1; i >= 0; i--) {
        if (a[i]) {
            return i;
        }
    }
    return -1;
}

class ECC_131 {
public:
    bitset<2 * SIZE> pow_coefficient;//x�ݴ�ϵ���б�
    bitset<2 * SIZE> r;//����ȥ��x^131

    ECC_131() { 
        this->r = bitset<2 * SIZE>("10000000000111"); 
    }

    ECC_131(bitset<2 * SIZE> p) { 
        this->pow_coefficient = p; 
        this->r = bitset<2 * SIZE>("10000000000111");
    }

    int getdegree() {
        for (int i = 2 * SIZE - 1; i >= 0; i--) {
            if (this->pow_coefficient[i] || i == 0) {
                return i;
            }      
        }
    }

    bool judge() {
        bitset<SIZE> temp;
        bitset<2 * SIZE> t(temp.set().to_string() + temp.to_string());
        t &=this->pow_coefficient;
        return t.any();
    }

    ECC_131 operator+(ECC_131& a) {
        ECC_131 ans;
        ans.pow_coefficient= this->pow_coefficient ^ a.pow_coefficient;
        return ans;
    }

    ECC_131 operator-(ECC_131& a) {
        ECC_131 ans;
        ans.pow_coefficient= this->pow_coefficient ^ a.pow_coefficient;
        return ans;
    }

    ECC_131 operator*(ECC_131& b) {
        ECC_131 x;
        bitset<2 * SIZE> temp(this->pow_coefficient.to_string());
        for (int i = 0; i < SIZE; i++) {
            if (b.pow_coefficient[i]) {
                x.pow_coefficient ^= temp << i;
            } 
        }
        return x%x;
    }

    bitset<2 * SIZE> operator*(bitset<2*SIZE>& b) {
        ECC_131 x;
        bitset<2 * SIZE> temp(this->pow_coefficient.to_string());
        for (int i = 0; i < SIZE; i++) {
            if (b[i]) {
                x.pow_coefficient ^= temp << i;
            }
        }
        return (x % x).pow_coefficient;
    }

    ECC_131 operator%(ECC_131 &rr) {
        ECC_131 x, y;
        x.pow_coefficient = this->pow_coefficient;
        y .pow_coefficient^= bitset<2 * SIZE>(x.pow_coefficient.to_string().substr(SIZE));
        while (x.judge()) {
            y.pow_coefficient.reset();
            y .pow_coefficient^= bitset<2 * SIZE>(x.pow_coefficient.to_string().substr(SIZE));
            for (int i = SIZE; i < 2 * SIZE; i++) {
                if (x.pow_coefficient[i]) {
                    y.pow_coefficient ^= rr.r << (i - SIZE);
                }
            }
            x.pow_coefficient = y.pow_coefficient;
        }
        ECC_131 ans;
        ans.pow_coefficient = bitset<2 * SIZE>(y.pow_coefficient.to_string().substr(SIZE));
        return ans;
    }

    friend ostream& operator<<(ostream& os, const ECC_131& D) {
        for (int i = SIZE-1; i >=0; i--) {
            if (D.pow_coefficient[i]&&i) {
                os <<"x^" << i << '+';
            }
            else if (D.pow_coefficient[i] && !i) {
                os << "1" << endl;
            }
        }
        return os;
    }
    //ƽ��
    ECC_131 square() {
        ECC_131 x;
        for (int i = 0; i < SIZE; i++)
            x.pow_coefficient[i * 2] = this->pow_coefficient[i];
        return (x%x);
    }

    ECC_131 inverse()////��չŷ������㷨����
    {
        bitset<SIZE + 1> p("111");
        p[131] = 1;
        p[13] = 1;
        bitset<2 * SIZE> b, c, temp;
        ECC_131 u, v;
        bitset<SIZE> r(p.to_string().substr(1));
        int j;
        b[0] = 1;
        u.pow_coefficient = bitset<2 * SIZE>(this->pow_coefficient.to_string());
        v.pow_coefficient = bitset<2 * SIZE>(p.to_string());
        while (u.getdegree())
        {
            j = u.getdegree() - v.getdegree();
            if (j < 0)
            {
                j = -j;
                temp = u.pow_coefficient;
                u = v;
                v = temp;
                temp = b;
                b = c;
                c = temp;
            }
            u = u.pow_coefficient ^ (v.pow_coefficient << j);
            b = b ^ (c << j);
        }
        ECC_131 ans(b);
        return ans % ans;//mod(b, r);
    }

    ECC_131 inverse_2() {//��������
        bitset<2*SIZE> b("11111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111110");//p-2
        bitset<2*SIZE> ans;//��ʼ������
        ans[0] = 1;
        ECC_131 answer(ans);
        ECC_131 a;
        a.pow_coefficient = this->pow_coefficient;
        while (get_index(b) != -1) {
            if (b[0] != 1) {
                b = b >> 1;
                a.pow_coefficient = a.square().pow_coefficient;
            }
            else {
                answer = (a * answer);
                b[0] = 0;
            }
        }
        return answer;
    }
    
};
