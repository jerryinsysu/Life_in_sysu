#include <iostream>
#include <vector>
#include <string>
#include "crypto_lab4.h"
using namespace std;

int main() {
    string message0 = "ilearnedhowtocalculatetheamountofpaperneededforaroomwheniwasatschoolyoumultiplythesquarefootageofthewallsbythecubiccontentsofthefloorandceilingcombinedanddoubleityouthenallowhalfthetotalforopeningssuchaswindowsanddoorsthenyouallowtheotherhalfformatchingthepatternthenyoudoublethewholethingagaintogiveamarginoferrorandthenyouorderthepaper";
    string key0 = "yuyi";
    string ID = "21312489";
    
    vector<int> message;
    vector<int> offset;
    vector<int> key;

    if (message0.size() % 16)
        message = padding(message0, 1);
    else 
        message = padding(message0, 1);
    if (key0.size() % 16) 
        key = padding(key0, 0);
    else 
        key = padding(key0, 0);
    if (!ID.size() % 16) 
        offset = padding(ID, 0);
    else 
        offset = padding(ID, 0);

    vector < vector<vector<int> > >cumm = encrypt_CBC(message, key, offset);
    vector<int> c1;
    for (int i = 0; i < cumm.size(); i++)
        col_output(cumm[i], "");
    for (int i = 0; i < cumm.size(); i++) 
        for (int j = 0; j < 4; j++) 
            for (int k = 0; k < 4; k++) 
                c1.push_back(cumm[i][k][j]);
    vector <vector<vector<int>>> m1 = decrypt_CBC(c1, key, offset);
    for (int i = 0; i < m1.size(); i++) 
        col_output(m1[i], "");
    return 0;
}