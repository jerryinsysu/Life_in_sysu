#include<iostream>
#include<bitset>
#include<vector>
#include<sstream>
#include <iomanip>
#include<random>
using namespace std;

// ��ʼ��ϣֵ�ĳ���
vector<string> hs1 = {
	"01101010000010011110011001100111",
	"10111011011001111010111010000101",
	"00111100011011101111001101110010",
	"10100101010011111111010100111010",
	"01010001000011100101001001111111",
	"10011011000001010110100010001100",
	"00011111100000111101100110101011",
	"01011011111000001100110100011001"
};

// �ֳ���
string ks[64] = {
	"01000010100010100010111110011000",
	"01110001001101110100010010010001",
	"10110101110000001111101111001111",
	"11101001101101011101101110100101",
	"00111001010101101100001001011011",
	"01011001111100010001000111110001",
	"10010010001111111000001010100100",
	"10101011000111000101111011010101",
	"11011000000001111010101010011000",
	"00010010100000110101101100000001",
	"00100100001100011000010110111110",
	"01010101000011000111110111000011",
	"01110010101111100101110101110100",
	"10000000110111101011000111111110",
	"10011011110111000000011010100111",
	"11000001100110111111000101110100",
	"11100100100110110110100111000001",
	"11101111101111100100011110000110",
	"00001111110000011001110111000110",
	"00100100000011001010000111001100",
	"00101101111010010010110001101111",
	"01001010011101001000010010101010",
	"01011100101100001010100111011100",
	"01110110111110011000100011011010",
	"10011000001111100101000101010010",
	"10101000001100011100011001101101",
	"10110000000000110010011111001000",
	"10111111010110010111111111000111",
	"11000110111000000000101111110011",
	"11010101101001111001000101000111",
	"00000110110010100110001101010001",
	"00010100001010010010100101100111",
	"00100111101101110000101010000101",
	"00101110000110110010000100111000",
	"01001101001011000110110111111100",
	"01010011001110000000110100010011",
	"01100101000010100111001101010100",
	"01110110011010100000101010111011",
	"10000001110000101100100100101110",
	"10010010011100100010110010000101",
	"10100010101111111110100010100001",
	"10101000000110100110011001001011",
	"11000010010010111000101101110000",
	"11000111011011000101000110100011",
	"11010001100100101110100000011001",
	"11010110100110010000011000100100",
	"11110100000011100011010110000101",
	"00010000011010101010000001110000",
	"00011001101001001100000100010110",
	"00011110001101110110110000001000",
	"00100111010010000111011101001100",
	"00110100101100001011110010110101",
	"00111001000111000000110010110011",
	"01001110110110001010101001001010",
	"01011011100111001100101001001111",
	"01101000001011100110111111110011",
	"01110100100011111000001011101110",
	"01111000101001010110001101101111",
	"10000100110010000111100000010100",
	"10001100110001110000001000001000",
	"10010000101111101111111111111010",
	"10100100010100000110110011101011",
	"10111110111110011010001111110111",
	"11000110011100010111100011110010"
};

// ������䵽�������ݵĺ���
string padding(string s, long long int n) {
	if (n % 2 != 0) {
		s.insert(n - 1, "0");
		n++;
	}
	s += "80";  // ����'1'λ��'0'λ
	long long int n1 = 0;
	long long int n11 = n + 2;
	if ((n11 < 112) || ((n11 - 112) % 128 != 0)) {
		long long int x = ((112 + 128) - (n11 % 128)) % 128;
		for (long long int i = 0; i < x; i++) {
			s += "0";  // ����0���
		}
	}
	n11 = n * 4 / 256;
	while (n11 != 0) {
		n1++;
		n11 /= 256;
	}

	for (long long int i = 0; i < (8 - n1) - 1; i++) s += "00";  // ���뵽8�ֽ�

	long long int n22 = pow(256, n1);
	long long int n3 = n * 4;
	while (n22 != 0) {
		long long int n2 = (n3 / n22);
		stringstream ss;
		ss << setfill('0') << setw(2) << hex << n2;
		s += ss.str();
		n3 %= n22;
		n22 /= 256;
	}

	return s;
}


// ���ַ���ת��Ϊ8λ�����ƿ�ĺ���
vector<bitset<8>> to_block(string s) {
	vector<bitset<8>> ans;
	for (long long int i = 0; i < s.length(); i += 2) {
		string byte = s.substr(i, 2);
		long long int n = std::stoi(byte, 0, 16);
		bitset<8> mid(n);
		ans.push_back(mid);
	}
	return ans;
}

// ��8λ�����ƿ�ת��Ϊ32λ�ֵĺ���
vector<bitset<32>> to_ws(vector<bitset<8>>& a) {
	vector<bitset<32>> ans;
	for (long long int i = 1; i <= a.size(); i += 4) {
		bitset<32> mid;
		for (long long int j = 0; j < 8; j++) {
			mid[3 * 8 + j] = a[i - 1][j];
			mid[2 * 8 + j] = a[i][j];
			mid[1 * 8 + j] = a[i + 1][j];
			mid[0 * 8 + j] = a[i + 2][j];
		}
		ans.push_back(mid);
	}
	return ans;
}

// ��32λ��ѭ������ָ��λ���ĺ���
bitset<32> rotate(bitset<32>& bits, long long int count) {
	count %= 32;
	return bits >> count | bits << (32 - count);
}

// SHA-256�е�o0���㺯��
bitset<32> o0(vector<bitset<32>>& w, long long int i) {
	bitset<32> mid1 = rotate(w[i], 7);
	bitset<32> mid2 = rotate(w[i], 18);
	bitset<32> mid3 = w[i] >> 3;
	bitset<32> ans = mid1 ^ mid2 ^ mid3;
	return ans;
}

// SHA-256�е�o1���㺯��
bitset<32> o1(vector<bitset<32>>& w, long long int i) {
	bitset<32> mid1 = rotate(w[i], 17);
	bitset<32> mid2 = rotate(w[i], 19);
	bitset<32> mid3 = w[i] >> 10;
	bitset<32> ans = mid1 ^ mid2 ^ mid3;
	return ans;
}

// SHA-256�е���Ϣ��չ����
vector<bitset<32>> w_padding(vector<bitset<32>>& ans) {
	for (long long int i = 16; i < 64; i++) {
		bitset<32> a = ans[i - 16];
		bitset<32> b = o0(ans, i - 15);
		bitset<32> c = ans[i - 7];
		bitset<32> d = o1(ans, i - 2);
		bitset<32> mid(a.to_ulong() + b.to_ulong() + c.to_ulong() + d.to_ulong());
		ans.push_back(mid);
	}
	return ans;
}

// SHA-256�е�ѹ������
bitset<32> temp1(bitset<32>& e, bitset<32>& f, bitset<32>& g, bitset<32>& h, vector<bitset<32>>& w1, vector<bitset<32>>& k1, long long int i) {
	bitset<32> sum1 = rotate(e, 6) ^ rotate(e, 11) ^ rotate(e, 25);
	bitset<32> e_ = e.flip();
	e.flip();
	bitset<32> choice = (e & f) ^ (e_ & g);
	bitset<32> ans(h.to_ulong() + sum1.to_ulong() + choice.to_ulong() + k1[i].to_ulong() + w1[i].to_ulong());
	return ans;
}

// SHA-256�е�ѹ������
bitset<32> temp2(bitset<32>& a, bitset<32>& b, bitset<32>& c) {
	bitset<32> sum0 = rotate(a, 2) ^ rotate(a, 13) ^ rotate(a, 22);
	bitset<32> majority = (a & b) ^ (a & c) ^ (b & c);
	bitset<32> ans(sum0.to_ulong() + majority.to_ulong());
	return ans;
}

// SHA-256 �е�ѹ������ H
vector<bitset<32>> H(vector<bitset<32>>& w1, vector<bitset<32>>& k1, vector<bitset<32>>& h1) {
	// ��ʼ��8��32λλ��
	bitset<32> a = h1[0];
	bitset<32> b = h1[1];
	bitset<32> c = h1[2];
	bitset<32> d = h1[3];
	bitset<32> e = h1[4];
	bitset<32> f = h1[5];
	bitset<32> g = h1[6];
	bitset<32> h = h1[7];

	for (long long int i = 0; i < 64; i++) {
		// ���� Temp1 �� Temp2
		bitset<32> Temp1 = temp1(e, f, g, h, w1, k1, i);
		bitset<32> Temp2 = temp2(a, b, c);

		// ���� h �� g, g �� f, �Լ� f �� e
		h = g;
		g = f;
		f = e;
		// ���� e
		bitset<32> mid(d.to_ulong() + Temp1.to_ulong());
		e = mid;
		// ���� d �� c, c �� b, �Լ� b �� a
		d = c;
		c = b;
		b = a;

		// ���� a
		bitset<32> mid1(Temp1.to_ulong() + Temp2.to_ulong());
		a = mid1;
	}

	// �����������
	vector<bitset<32>> result;
	bitset<32> mida(a.to_ulong() + h1[0].to_ulong());
	bitset<32> midb(b.to_ulong() + h1[1].to_ulong());
	bitset<32> midc(c.to_ulong() + h1[2].to_ulong());
	bitset<32> midd(d.to_ulong() + h1[3].to_ulong());
	bitset<32> mide(e.to_ulong() + h1[4].to_ulong());
	bitset<32> midf(f.to_ulong() + h1[5].to_ulong());
	bitset<32> midg(g.to_ulong() + h1[6].to_ulong());
	bitset<32> midh(h.to_ulong() + h1[7].to_ulong());
	result.push_back(mida);
	result.push_back(midb);
	result.push_back(midc);
	result.push_back(midd);
	result.push_back(mide);
	result.push_back(midf);
	result.push_back(midg);
	result.push_back(midh);

	return result;
}


// SHA-256 ������
string Sha256(string s) {
	vector<string> hs = hs1;
	s = padding(s, s.length());
	// �������ַ���ת��Ϊ���ؿ�
	vector<bitset<8>> w1 = to_block(s);
	vector<bitset<32>> w0 = to_ws(w1);

	// ��ʼ�� h��k �� w
	vector<bitset<32>> h;
	for (long long int i = 0; i < hs.size(); i++) {
		bitset<32> mid(hs[i]);
		h.push_back(mid);
	}
	vector<bitset<32>> k;
	for (long long int i = 0; i < (sizeof(ks) / sizeof(ks[0])); i++) {
		bitset<32> mid(ks[i]);
		k.push_back(mid);
	}

	vector<vector<bitset<32>>> w;
	for (long long int i = 0; i < (w0.size() / 16); i++) {
		vector<bitset<32>> mid;
		for (long long int j = 0; j < 16; j++) {
			mid.push_back(w0[i * 16 + j]);
		}
		w.push_back(mid);
	}

	vector<bitset<32>> result;
	for (long long int i = 0; i < w.size(); i++) {
		vector<bitset<32>> mid = w[i];
		mid = w_padding(mid);
		h = H(mid, k, h);
		result = h;
	}
	stringstream ss;
	for (long long int j = 0; j < 8; j++) {
		for (long long int i1 = 0; i1 < 4; i1++) {
			bitset<8> mid(result[j].to_string().substr(i1 * 8, 8));
			ss << setw(2) << setfill('0') << hex << mid.to_ulong();
		}
	}
	return ss.str();
}

// ���ַ���ת��ΪASCIIʮ�����Ʊ�ʾ
string string2asc(const string& s) {
	ostringstream asciiString;
	for (char c : s) {
		asciiString << setw(2) << setfill('0') << hex << static_cast<int>(c);
	}
	string ans = asciiString.str();
	return ans;
}