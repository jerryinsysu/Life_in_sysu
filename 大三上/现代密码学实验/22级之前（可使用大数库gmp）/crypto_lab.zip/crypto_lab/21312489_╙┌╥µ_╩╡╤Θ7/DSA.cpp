#include "Midware.h"
#include "SHA256.h"
using namespace std;

// DSAǩ��
void DSA_si(mpz_class p, mpz_class q, mpz_class alpha, mpz_class a, mpz_class& gamma, mpz_class& delta, mpz_class msg) {
	cout << "========================================================================================" << endl
		<< "��DSAǩ����" << endl;
	mpz_class k = perKey_RandGen(q); //ÿ�ζ����
	if (gamma_calculate(alpha, k, p, q) != 0 && delta_calculate(msg, a, gamma, k, q) != 0) {//�����Ƿ�Ϊ0
		gamma = gamma_calculate(alpha, k, p, q);
		delta = delta_calculate(msg, a, gamma, k, q);
	}
	else {
		Sleep(1);//����һ��ʱ�䵱������
		k = perKey_RandGen(q);
		gamma = gamma_calculate(alpha, k, p, q);
		delta = delta_calculate(msg, a, gamma, k, q);
	}
	cout << "k(random) =\t" << k << endl;
	cout << "gamma =\t" << gamma << endl;
	cout << "delta =\t" << delta << endl;
	cout << endl;
}

// DSA��֤ǩ��
void DSA_design(mpz_class p, mpz_class q, mpz_class alpha, mpz_class a, mpz_class gamma, mpz_class delta, mpz_class msg,mpz_class beta) {
	cout << "========================================================================================" << endl 
		<< "��DSA��֤ǩ����" << endl;
	mpz_class w;
	mpz_class temp;
	mpz_class u1;
	mpz_class u2;
	mpz_class _temp;
	mpz_class v;
	if (gamma > q || gamma < 0 || delta > q || delta < 0) {//ֱ���ȶ���
		goto Err;
	}
	//������֤����
	mpz_invert(w.get_mpz_t(), delta.get_mpz_t(), q.get_mpz_t());
	u1 = msg * w % q; u2 = gamma * w % q;
	mpz_powm(temp.get_mpz_t(), alpha.get_mpz_t(), u1.get_mpz_t(), p.get_mpz_t());
	mpz_powm(_temp.get_mpz_t(), beta.get_mpz_t(), u2.get_mpz_t(), p.get_mpz_t());
	v = temp * _temp % p % q;
	
	if (v == gamma) {
		cout << "w =\t" << w << endl;
		cout << "u1 =\t" << u1 << endl;
		cout << "u2 =\t" << u2 << endl;
		cout << "v =\t" << v << endl;
	
		cout << "========================================================================================" << endl
			<< "��DSA��֤�����" << endl << "True!" << endl;
		goto End;
	}
	else {
		cout << "w =\t" << w << endl;
		cout << "u1 =\t" << u1 << endl;
		cout << "u2 =\t" << u2 << endl;
		cout << "v =\t" << v << endl;
	Err:
		cout << "========================================================================================" << endl
			<< "��DSA��֤�����" << endl << "Error!" << endl;
		goto End;
	}

End:
	return;
}
void DSA_sign_design(mpz_class p, mpz_class q, mpz_class alpha, mpz_class a, mpz_class gamma, mpz_class delta, mpz_class msg,mpz_class beta ) {
	DSA_si(p, q, alpha, a, gamma, delta, msg);
	DSA_design(p, q, alpha, a, gamma, delta, msg,beta);
}

// ������
int main() {
//�ο���վ���ɵĲ���
	mpz_class p("29096620326607064822357161179722848401706200555289807686407398574210652875771186082004715210238414433625537725530898234075179518492018418886641818208303915553473024195781885368831399098732251206517838507101330124914544817175169704813998617946243014763395415066408169051397146526325957948160817434678457525082957705085727086584895533173945770047913924217439270909280394329692154760092997887419148054836738122520335000791553641664054923743729248131141066502075362041235926126304745847936095673762224826120350913951440627045440099637206868080093670736922354744364230320474703034106216533664740090249582416251095375537473");
	mpz_class q("70786908566706074888765096900589808332901311463316188101568943828123382856093");
	mpz_class alpha("22911691406422375414907856233797566044368224735056335242381610321046337124259243954143814951277820412492861436124870497392892396576646005172767157510295380394583406610772571366504609574532882663180688298283079636006130393193300367935482085773034791214745364061621694543023053290451225457835343861457730476094059271292652427522736008632456421284128073395028416693710598887456772635540622462311003762648522226534447017122553070413674428254791316746625932406227185039520724693601801371583956455082482489923860681632732685228068042141536199888368821292467693698826103010337167107942426972932828559359939080448745223645973");
	//����˽Կa
	mpz_class a("114514");

	// ��Ϣԭ��
	string m = "sysu21312489yuyi2023";
	cout << "����չʾ:" << endl;
	cout << "msg:\t" << m << endl;
	cout << "p:\t" << p << endl;
	cout << "q:\t" << q << endl;
	cout << "alpha:\t" << alpha << endl;
	cout << "a:\t" << a << endl;

	ostringstream asciiString;
	for (char c : m) 
		asciiString << setw(2) << setfill('0') << hex << static_cast<int>(c);

	cout << "0xmsg=\t" << asciiString.str() << endl;
	//�ֽڴ���ϣ
	mpz_class message("0x" + Sha256(asciiString.str()));

	// ����betaֵ����֤��ֵΪ��17094175466876115900957999415229689246325183330879309340773950052811940582881576383323239649886521760211593467575377258533440676878958198134987521687599026161306641831763888353111043411595602863244394349108038705490881483973903544686383461635657311358559899068842046844755653920290781741541830581780141550145098865208009107466119014798298246553939672117895691994596479332412400805580517494429643298745368648188418233564201576680055759867707248663067116592799284181072778471606574372536210386038450964928317732721594614359624148822821943628297198705255632727564532753813654128732569057772988319756728575952060188004372
	mpz_class beta;
	mpz_powm(beta.get_mpz_t(), alpha.get_mpz_t(), a.get_mpz_t(), p.get_mpz_t());
	
	cout<< "beta(��Կ):\t" << beta << endl;
	
	mpz_class gamma;
	mpz_class delta;

	DSA_sign_design(p, q, alpha, a, gamma, delta, message,beta);

	return 0;
}