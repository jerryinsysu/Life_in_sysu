#### 计图小组作业提交情况

>下面的这个链接是我们的github链接，里面有小组成员的实现部分、我们代码的完整实现并且有上传可以运行的程序（不过具体要求要看仓库的readme才可以正常运行）
>
>[第六小组烟花粒子实现](https://github.com/SYSU-graph/OpenGL-particle)（链接重新更新）
>
>下面这个链接是我们的视频效果链接
>
>[视频最终效果](https://www.bilibili.com/video/BV1PukrYTE5e/?spm_id_from=333.999.0.0&vd_source=78e6b9f94832311a437e4c29351efb10)
>
>剩下的内容，我们是按照要求来存放的（已经提前跟助教说明过了）