#include "bitmap.h"
#include "stdlib.h"
#include "stdio.h"

BitMap::BitMap()
{
}

void BitMap::initialize(char *bitmap, const int length)
{
    this->bitmap = bitmap;
    this->length = length;

    int bytes = ceil(length, 8);

    for (int i = 0; i < bytes; ++i)
    {
        bitmap[i] = 0;
    }
}

bool BitMap::get(const int index) const
{
    int pos = index / 8;
    int offset = index % 8;

    return (bitmap[pos] & (1 << offset));
}

void BitMap::set(const int index, const bool status)
{
    int pos = index / 8;
    int offset = index % 8;

    // 清0
    bitmap[pos] = bitmap[pos] & (~(1 << offset));

    // 置1
    if (status)
    {
        bitmap[pos] = bitmap[pos] | (1 << offset);
    }
}

int BitMap::allocate(const int count)
{
    if (count == 0)
        return -1;

    int index, empty, start;

    index = 0;
    int smallest = 0xfffff;
    int smallest_start = -1;

//从头到尾遍历一次现有页
while(index < length)
{
    //越过已经分配的资源
    while(index < length && get(index))
        ++index;
    
    //不存在连续的count个资源
    if(index==length)
        return -1;

    //此时找到一个可供分配的资源
    //开始检查是否存在从index开始的连续count个资源
    empty = 0;
    start = index;
    while ((index < length) && !get(index))
    {
        empty++; //增加可分配页面数量
        index++; //索引增加
    }

    if(empty >= count && empty < smallest)
    {
        smallest = empty;
        smallest_start = start;
    }
}

if(smallest_start != -1)
{
    for(int i=0; i<count; i++)
    {
        set(smallest_start+i, true);
    }
}
    return smallest_start;
   
}

void BitMap::release(const int index, const int count)
{
    for (int i = 0; i < count; ++i)
    {
        set(index + i, false);
    }
}

char *BitMap::getBitmap()
{
    return (char *)bitmap;
}

int BitMap::size() const
{
    return length;
}
