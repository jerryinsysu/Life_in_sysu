#ifndef ENTRY_H
#define ENTRY_H

extern "C" void setup_kernel();

#endif