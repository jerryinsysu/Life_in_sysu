#include "asm_utils.h"
#include "interrupt.h"
#include "stdio.h"
#include "program.h"
#include "thread.h"
#include "sync.h"
#define DELAY 0x0ffffff

// 屏幕IO处理器
STDIO stdio;
// 中断管理器
InterruptManager interruptManager;
// 程序管理器
ProgramManager programManager;

// 初始化5根筷子的信号量
Semaphore sign_1, sign_2, sign_3, sign_4, sign_5;

// 将延时过程单独表示一个函数，便于后面代码
void wait(int delay = DELAY){
	while (delay)
		--delay;
}

void a1(void *arg)
{
	for(int e = 0; e < 20; e++){
		sign_5.P(); //先拿起左边的筷子
		wait(); 
		sign_1.P(); //后拿起右边的筷子
		printf("1   ");
		wait();
		sign_1.V();
		sign_5.V();
	}
}

void a2(void *arg) //偶数号哲学家则相反
{
	for(int e = 0; e < 20; e++){
	   	sign_2.P(); //先拿起右边的筷子
		wait();
	   	sign_1.P(); //再拿起左边的筷子
		printf("2   ");
		wait();
		sign_1.V();
		sign_2.V();
	}
}

void a3(void *arg)
{
	for(int e = 0; e < 20; e++){
	   	sign_2.P();
		wait();
	   	sign_3.P();
		printf("3   ");
		wait();
		sign_3.V();
		sign_2.V();
	}
}

void a4(void *arg)
{
	for(int e = 0; e < 20; e++){
	   	sign_4.P();
		wait();
	   	sign_3.P();
		printf("4   ");
		wait();
		sign_3.V();
		sign_4.V();
	}
}

void a5(void *arg)
{
	for(int e = 0; e < 20; e++){
	   	sign_4.P();
		wait();
	   	sign_5.P();
		printf("5   ");
		wait();
		sign_5.V();
		sign_4.V();
	}
}

void first_thread(void *arg)
{
    // 第1个线程不可以返回
    stdio.moveCursor(0);
    for (int i = 0; i < 25 * 80; ++i)
    {
        stdio.print(' ');
    }
    stdio.moveCursor(0);

    sign_1.initialize(1);
    sign_2.initialize(1);
    sign_3.initialize(1);
    sign_4.initialize(1);
    sign_5.initialize(1);

    programManager.executeThread(a1, nullptr, "1 thread", 1);
    programManager.executeThread(a2, nullptr, "2 thread", 1);
    programManager.executeThread(a3, nullptr, "3 thread", 1);
    programManager.executeThread(a4, nullptr, "4 thread", 1);
    programManager.executeThread(a5, nullptr, "5 thread", 1);

    asm_halt();
}

extern "C" void setup_kernel()
{

    // 中断管理器
    interruptManager.initialize();
    interruptManager.enableTimeInterrupt();
    interruptManager.setTimeInterrupt((void *)asm_time_interrupt_handler);

    // 输出管理器
    stdio.initialize();

    // 进程/线程管理器
    programManager.initialize();

    // 创建第一个线程
    int pid = programManager.executeThread(first_thread, nullptr, "first thread", 1);
    if (pid == -1)
    {
        printf("can not execute thread\n");
        asm_halt();
    }

    ListItem *item = programManager.readyPrograms.front();
    PCB *firstThread = ListItem2PCB(item, tagInGeneralList);
    firstThread->status = RUNNING;
    programManager.readyPrograms.pop_front();
    programManager.running = firstThread;
    asm_switch_thread(0, firstThread);

    asm_halt();
}
