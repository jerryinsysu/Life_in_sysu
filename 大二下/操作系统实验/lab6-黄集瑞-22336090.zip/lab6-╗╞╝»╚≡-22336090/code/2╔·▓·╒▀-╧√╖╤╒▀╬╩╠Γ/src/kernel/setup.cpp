#include "asm_utils.h"
#include "interrupt.h"
#include "stdio.h"
#include "program.h"
#include "thread.h"
#include "sync.h"

// 屏幕IO处理器
STDIO stdio;
// 中断管理器
InterruptManager interruptManager;
// 程序管理器
ProgramManager programManager;

Semaphore semaphore;

int shared_variable;

char msg_1[100]={'O','N','E'};
char msg_2[100]={'T','W','O'};
char msg_3[100]={'T','H','R','E','E'};
char msg_4[100]={'F','O','U','R'};


void readFirstQuote(void *arg)
{
    printf("the first quote: %s\n", msg_1);
}

void readSecondQuote(void *arg)
{
    semaphore.P();   
    printf("the second quote: %s\n", msg_2);
    semaphore.V();
}

void readThirdQuote(void *arg)
{
    printf("the third quote: %s\n", msg_3);
}

void readFourthQuote(void *arg)
{
    semaphore.P();
    printf("the fourth quote: %s\n", msg_4);
    semaphore.V();
}


void writeSecondQuote(void *arg)
{
    char* str = "Do not go gentle into that good night.";
    int i = 0;
    semaphore.P();
    int delay = 0xfffffff;
    while(delay)
	--delay; 
    while(str[i] != '\0' && i < 99)
    {
        msg_2[i] = str[i];
        i++;
    }
    msg_2[i] = '\0';
    semaphore.V();
}

void writeFourthQuote(void *arg)
{
    char* str = "Old age should burn and rave at close of day.";
    int i = 0;
    semaphore.P();
    int delay = 0;
    delay = 0xfffffff;
    while(delay)
	--delay; 
    while(str[i] != '\0' && i < 99)
    {
        msg_4[i] = str[i];
        i++;
    }
    msg_4[i] = '\0';
    semaphore.V();
}


void first_thread(void *arg)
{
    // 第1个线程不可以返回
    stdio.moveCursor(0);
    for (int i = 0; i < 25 * 80; ++i)
    {
        stdio.print(' ');
    }
    stdio.moveCursor(0);

    semaphore.initialize(1);

    //模拟读错误
    //创建线程读第1-4条记录
    programManager.executeThread(readFirstQuote, nullptr, "second thread", 1);
    programManager.executeThread(readSecondQuote, nullptr, "third thread", 1);
    programManager.executeThread(readThirdQuote, nullptr, "fourth thread", 1);
    programManager.executeThread(readFourthQuote, nullptr, "fifth thread", 1);
    //创建线程，修改第2条和第4条记录为较长内容
    //由于写时间较长，写线程运行时间大于RRschedule的time quantum
    programManager.executeThread(writeSecondQuote, nullptr, "sixth thread", 1);
    programManager.executeThread(writeFourthQuote, nullptr, "seventh thread", 1);
    //创建线程读第2条和第4条记录
    //发现没有读到修改后的项，而是输出了初始项
    programManager.executeThread(readSecondQuote, nullptr, "eighth thread", 1);
    programManager.executeThread(readFourthQuote, nullptr, "ninth thread", 1);
    asm_halt();
}

extern "C" void setup_kernel()
{

    // 中断管理器
    interruptManager.initialize();
    interruptManager.enableTimeInterrupt();
    interruptManager.setTimeInterrupt((void *)asm_time_interrupt_handler);

    // 输出管理器
    stdio.initialize();

    // 进程/线程管理器
    programManager.initialize();

    // 创建第一个线程
    int pid = programManager.executeThread(first_thread, nullptr, "first thread", 1);
    if (pid == -1)
    {
        printf("can not execute thread\n");
        asm_halt();
    }

    ListItem *item = programManager.readyPrograms.front();
    PCB *firstThread = ListItem2PCB(item, tagInGeneralList);
    firstThread->status = RUNNING;
    programManager.readyPrograms.pop_front();
    programManager.running = firstThread;
    asm_switch_thread(0, firstThread);

    asm_halt();
}

