#include<iostream>
using namespace std;
extern "C" void function_from_asm();

int main()
{
    cout << "Call function from assembly." << endl;
    function_from_asm();
    cout << "Done." << endl;
}
