class Weici:
    def __init__(self, clause):
        self.element=[] #将子句进行拆分
        if len(clause)!=0: #有效输入才进行下一步
            if clause[0]==',': #因为我们采用‘)’划分，如有多个谓词就需要把前面‘,’删掉
                clause=clause[1:]
            tmp=''
            for i in range(len(clause)):
                tmp+=clause[i]
                if clause[i]=='(' or clause[i]==')' or clause[i]==',': #将输入的子句分为谓词，以及单个文字
                    self.element.append(tmp[:-1])
                    tmp=''

    def is_negative(self):
        if self.element[0][0] == '~':
            return True
        else:
            return False


    def get_name_of_clause(self):
        if self.is_negative():
            return self.element[0][1:] #需要注意的是，此时element[0]为str类型，故多加上[1:]来取值前面的取反
        else:
            return self.element[0]
        
    def new(self, clause):
        for i in range(len(clause)):
            self.element.append(clause[i])

    def rename(self, old_name, new_name):
        for i in range(len(old_name)):
            j = 1 # 因为谓词不需要改变，所以下标从1开始即可
            while j < len(self.element):
                if self.element[j]==old_name[i]:
                    self.element[j]=new_name[i]
                j = j+1

def print_msg(key,i,j,old_name,new_name,set_for_KB):
    tmp = str(len(set_for_KB)) + " R[" + str(i+1) #因为此时只为一个谓词
    if len(new_name) ==0 and len(set_for_KB[i]) !=1:
        tmp = tmp + chr(key + 97) #表示合一的式子
    tmp = tmp + ", " + str(j+1) + chr(key+97) + "]{" #添加合一相关的索引信息
    for k in range(len(old_name)):
        tmp = tmp + old_name[k] + "=" + new_name[k] #添加置换的值
        if k < len(old_name) - 1:
           tmp = tmp + ", "
    tmp = tmp + "} = "
    print(tmp, end="")


def end_or_not(new_clause, set_of_clause):
    if len(new_clause) == 0: #新生成的子句为空
        print("[]")
        return True
    if len(new_clause) == 1:  # 查找已有的子句中是否存在与新子句互补
        for i in range(len(set_of_clause) - 1):  # set_of_clause[j]超过一个谓词的取或的子句
            if len(set_of_clause[i]) == 1 and new_clause[0].get_name_of_clause() == set_of_clause[i][0].get_name_of_clause() and new_clause[0].element[1:] == \
                    set_of_clause[i][0].element[1:] and new_clause[0].is_negative() != set_of_clause[i][0].is_negative():
                print(len(set_of_clause) + 1, " R[", i + 1, ", ", len(set_of_clause), "] = []", sep="")
                return True
    return False  # 不符合条件不结束    


def Pre_processing(KB):
    #因为输入的子句集为集合，而其中的子句类型为元组无法被改变，所以更改对应的数据类型
    KB_list=[]
    for rule in KB:
        rule = list(rule)
        KB_list.append(rule)
    #定义一个列表来接收处理好的谓词
    set_for_KB = []
    tmp=''
    for i in range(len(KB_list)):
        set_for_KB.append([])
        for j in range(len(KB_list[i])):
            for k in range(len(KB_list[i][j])):
                tmp = tmp + KB_list[i][j][k]
                # print(tmp)
                # print('**********')
                if KB_list[i][j][k]==')': #利用‘)’作为标志来区分多个谓词
                    clause = Weici(tmp)
                    set_for_KB[i].append(clause)
                    tmp='' #此时更新tmp
    # for i in range(len(set_for_KB)):
    #     for j in range(len(set_for_KB[i])):
    #         print(set_for_KB[i][j].element)
    #     print('-------------------------------')
    
    return set_for_KB, KB_list
# 至此我们便实现了谓词划分                    



def print_clause(KB_list):
    for i in range(len(KB_list)):
        print(str(i+1) + ' (',end='')
        for j in range(len(KB_list[i])):
            if j == len(KB_list[i])-1 and j != 0 :
                print(KB_list[i][j],end='')
            else:
                print(KB_list[i][j]+',',end='')
        print(')')    
#用来打印子句

def print_new_clause(clause):
    if len(clause) != 0:
        tmp = ""
        tmp = tmp+'('
        flag = 0
    for i in range(len(clause)):
        tmp = tmp + clause[i].element[0] +'(' #先加上谓词
        for j in range(1, len(clause[i].element)):
            tmp += clause[i].element[j]
            if j < len(clause[i].element)-1: #多元谓词考虑
                tmp = tmp + ','
        tmp = tmp +')' #一个子句的完结
        if i < len(clause)-1: #考虑多个谓词
            tmp = tmp + ','
            flag = 1
        if not flag:
            tmp = tmp + ','
    tmp = tmp + ")"
    if (tmp != ""):
        print(tmp)



def ResolutionFOL(rules):
    set_for_KB, KB_list = Pre_processing(rules)
    #接下来按照顺序打印原先的子句
    print_clause(KB_list)
    
    #接下来就要进行归结步骤
    flag = True
    while flag:
        for i in range(len(set_for_KB)):
            if not flag:
                break
            if len(set_for_KB[i])==1: #此时只对一个谓词的语句进行分析
                for j in range(len(set_for_KB)):
                    if not flag:
                        break
                    if i==j:
                        continue #谓词自身不能进行比较
                    old_name=[]
                    new_name=[] #新旧名字保存
                    key = -1 #表示该子句的同名谓词不可以被消去
                    for k in range(len(set_for_KB[j])):
                        if set_for_KB[i][0].get_name_of_clause() == set_for_KB[j][k].get_name_of_clause() and set_for_KB[i][0].is_negative() != set_for_KB[j][k].is_negative() :
                        # 此条件是由于因为此时分析单个谓词语句，所以set_for_KB[i][0]就是唯一的谓词，并且要实现合一必须要有相反的谓词，故有此条件
                            key = k #记录一下位置
                            for l in range(1,len(set_for_KB[j][k].element)): #element首个元素为谓词，故直接跳过就行
                                if len(set_for_KB[j][k].element[l])==1 or len(set_for_KB[j][k].element[l])==2: #由于例子中变量均小于2个字符，所以此时为自由变量
                                    old_name.append(set_for_KB[j][k].element[l])
                                    new_name.append(set_for_KB[i][0].element[l])
                                    #此时锁定在同个谓词，故替换变量位置固定
                                elif len(set_for_KB[i][0].element[l])==1 or len(set_for_KB[i][0].element[l])==2:
                                    old_name.append(set_for_KB[i][0].element[l])
                                    new_name.append(set_for_KB[j][k].element[l])
                                elif set_for_KB[i][0].element[l] != set_for_KB[j][k].element[l]:
                                    key = -1
                                    break #有一处不能替换就退出
                            break #若是此时不能替换，直接退出/若是遍历完毕了，也可以直接退出不用在遍历第二个进行重复操作
                    if key == -1: #说明该子句无法进行置换
                        continue
                    new_clause = [] #记录新生成的子句

                    for k in range(len(set_for_KB[j])):
                        if k!=key: #位置为key的谓词已被置换，所以不放入新的子句集中
                            n = Weici("")
                            n.new(set_for_KB[j][k].element)
                            n.rename(old_name, new_name)
                            new_clause.append(n)
                    if len(new_clause) == 1: # 判断生成的子句是否与原有重复
                        for k in range(len(set_for_KB)):
                            if len(set_for_KB[k])==1 and new_clause[0].element == set_for_KB[k][0].element:
                                key = -1
                                break
                    if key==-1: #若为重复子句，则不进行加入新子句集当中
                        continue
                    set_for_KB.append(new_clause) #加入原有的子句集当中
                    print_msg(key, i, j, old_name, new_name, set_for_KB)
                    print_new_clause(new_clause)
                    if end_or_not(new_clause, set_for_KB):  # 判断是否应该结束归结过程
                        flag = False
                        break

# 上面的步骤完成的是针对与仅有一个谓词的子句，接下来实现有多个谓词的子句
            else:
                for j in range(len(set_for_KB)):
                    key = -1 #表示该同名谓词不可消去
                    if i != j and len(set_for_KB[i]) == len(set_for_KB[j]): #先要保障长度一致
                        for k in range(len(set_for_KB[i])):
                            if set_for_KB[i][k].element == set_for_KB[j][k].element: #排除掉对同一谓词的重复操作
                                continue
                            elif set_for_KB[i][k].get_name_of_clause() == set_for_KB[j][k].get_name_of_clause() and set_for_KB[i][k].element[1:]==set_for_KB[j][k].element[1:]:
                                if key != -1: #表明不使用该规则进行合一化处理
                                    key = -1
                                    break
                                key = k
                            else:
                                key = -1
                                break
                    if key==-1: #说明此时无法进行合一化
                        continue
                    new_clause = []
                    # 接下来操作与单个谓词的如出一辙
                    for k in range(set_for_KB[i]):
                        if k!=key:
                            n = Weici("")
                            n.new(set_for_KB[j][k].element)
                            new_clause.append(n)
                    if len(new_clause) == 1:  # 判断是否生成的子句是否与已有重复
                        for k in range(len(set_for_KB)):
                            if len(set_for_KB[k]) == 1 and new_clause[0].element == set_for_KB[k][0].element:
                                key = -1
                                break
                    if key == -1:
                        continue
                    set_for_KB.append(new_clause)
                    print_msg(key, i, j, [], [], set_for_KB)  # 输出生成新子句的相关信息
                    print_new_clause(new_clause)  # 输出该新子句                    
                    if end_or_not(new_clause, set_for_KB):  # 判断是否应该结束归结过程
                        flag = False
                        break



#set接收list数据类型作为输入
#KB = set([('GradStudent(sue)',),('~GradStudent(x)','Student(x)'),('~Student(x)','HardWorker(x)'),('~HardWorker(sue)',)])
# ResolutionFOL(KB)

#KB = set([('A(tony)',),('A(mike)',),('A(john),'),('L(tony,rain)',),('L(tony,snow)',),('~A(x)','S(x)','C(x)'), ('~C(y)','~L(y,rain)'),('L(z,snow)','~S(z)'),('~L(tony,u)','~L(mike,u)'),('L(tony,v)','L(mike,v)'),('~A(w)','~C(w)','S(w)')])
# ResolutionFOL(KB)

KB = set([('On(tony,mike)',),('On(mike,john)',),('Green(tony)',),('~Green(john)',), ('~On(xx,yy)','~Green(xx)','Green(yy)')])
ResolutionFOL(KB)

