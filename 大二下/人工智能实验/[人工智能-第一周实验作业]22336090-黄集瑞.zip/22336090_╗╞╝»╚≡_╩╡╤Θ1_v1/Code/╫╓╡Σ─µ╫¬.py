def ReverseKeyValue(dict1):
    """
    :param dict1: dict
    :return: dict
    """
    dict2 = {}
    for it in dict1.items():
        dict2[it[1]] = it[0] # 因为发现此时it为元组结构，故利用下标交换
    return dict2

dict1={'Alice':'001', 'Bob':'002'}
dict2 = ReverseKeyValue(dict1)
print(dict2)