def MatrixAdd(A, B):
    """
    :param A: list[list[int]]
    :param B: list[list[int]]
    :return: list[list[int]]
    """
    lenth = len(A) # 获取矩阵的大小
    C = [[0 for i in range(lenth)] for j in range(lenth)] # 初始化一个矩阵
    for i in range(lenth):
        for j in range(lenth):
            C[i][j] = A[i][j] + B[i][j]
    return C


A = [[1,2],[3,4]]
B = [[5,6],[7,8]]
C = MatrixAdd(A,B)
print(C)

def MatrixMul(A, B):
    """
    :param A: list[list[int]]
    :param B: list[list[int]]
    :return: list[list[int]]
    """
    lenth = len(A) # 获取矩阵的大小
    C = [[0 for i in range(lenth)] for j in range(lenth)] # 初始化一个矩阵
    for i in range(lenth):
        for j in range(lenth):
            for k in range(lenth):
                C[i][j] += A[i][k] * B[k][j]
    return C

A = [[1,2],[3,4]]
B = [[5,6],[7,8]]
C = MatrixMul(A,B)
print(C)