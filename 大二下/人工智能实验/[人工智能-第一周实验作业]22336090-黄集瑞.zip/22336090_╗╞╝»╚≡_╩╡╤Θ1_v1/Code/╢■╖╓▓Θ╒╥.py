
def BinarySearch(nums, target):
    """
    :param nums: list[int]
    :param target: int
    :return: int
    """
    lenth = len(nums) # 获取列表长度
    if lenth==0:
        return -1 # 若该列表为空直接返回-1
    min = 0
    max = lenth-1
    while min <= max:
        mid = (min+max)//2
        if target == nums[mid]:
            return mid
        elif target > nums[mid]:
            min = mid+1
        elif target < nums[mid]:
            max = mid-1
    return -1

x = [1,3,5,7,11,13,17,19]
y = []
result1 = BinarySearch(x,2)
result2 = BinarySearch(x,11)
result3 = BinarySearch(y,10)
print(result1)
print(result2)
print(result3)