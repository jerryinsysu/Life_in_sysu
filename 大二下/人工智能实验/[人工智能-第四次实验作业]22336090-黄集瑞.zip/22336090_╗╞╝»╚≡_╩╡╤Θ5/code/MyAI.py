import copy
import random
from ChessBoard import *
MAX_DEPTH = 5

class Evaluate(object):
    # 棋子棋力得分
    single_chess_point = {
        'c': 989,   # 车
        'm': 439,   # 马
        'p': 442,   # 炮
        's': 226,   # 士
        'x': 210,   # 象
        'z': 55,    # 卒
        'j': 65536  # 将
    }
    # 红兵（卒）位置得分
    red_bin_pos_point = [
        [1, 3, 9, 10, 12, 10, 9, 3, 1],
        [18, 36, 56, 95, 118, 95, 56, 36, 18],
        [15, 28, 42, 73, 80, 73, 42, 28, 15],
        [13, 22, 30, 42, 52, 42, 30, 22, 13],
        [8, 17, 18, 21, 26, 21, 18, 17, 8],
        [3, 0, 7, 0, 8, 0, 7, 0, 3],
        [-1, 0, -3, 0, 3, 0, -3, 0, -1],
        [0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0],
    ]
    # 红车位置得分
    red_che_pos_point = [
        [206,208,207,213,214,213,207,208,206],  
        [206,212,209,216,233,216,209,212,206],  
        [206,208,207,214,216,214,207,208,206],  
        [206,213,213,216,216,216,213,213,206],  
        [208,211,211,214,215,214,211,211,208],  
        [208,212,212,214,215,214,212,212,208],  
        [204,209,204,212,214,212,204,209,204],  
        [198,208,204,212,212,212,204,208,198],  
        [200,208,206,212,200,212,206,208,200],  
        [194,206,204,212,200,212,204,206,194],
    ]
    # 红马位置得分
    red_ma_pos_point = [
        [90, 90, 90, 96, 90, 96, 90, 90, 90],
        [90, 96,103, 97, 94, 97,103, 96, 90],
        [92, 98, 99,103, 99,103, 99, 98, 92],
        [93,108,100,107,100,107,100,108, 93],
        [90,100, 99,103,104,103, 99,100, 90],
        [90, 98,101,102,103,102,101, 98, 90],
        [92, 94, 98, 95, 98, 95, 98, 94, 92],
        [90, 92, 95, 95, 92, 95, 95, 92, 90],
        [85, 90, 92, 93, 78, 93, 92, 90, 85],
        [88, 50, 90, 88, 90, 88, 90, 50, 88],
    ]
    # 红炮位置得分
    red_pao_pos_point = [
        [100,100, 96, 91, 90, 91, 96,100,100],
        [98, 98, 96, 92, 89, 92, 96, 98, 98],
        [97, 97, 96, 91, 92, 91, 96, 97, 97],
        [96, 99, 99, 98,100, 98, 99, 99, 96],
        [96, 96, 96, 96,100, 96, 96, 96, 96],
        [95, 96, 99, 96,100, 96, 99, 96, 95],
        [96, 96, 96, 96, 96, 96, 96, 96, 96],
        [97, 96,100, 99,101, 99,100, 96, 97],
        [96, 97, 98, 98, 98, 98, 98, 97, 96],
        [96, 96, 97, 99, 99, 99, 97, 96, 96],
    ]
    # 红将位置得分
    red_jiang_pos_point = [
        [0,  0,  0,  12000,  12000,  12000,  0,  0,  0],  
        [0,  0,  0,  12000,  12000,  12000,  0,  0,  0],  
        [0,  0,  0,  12000,  12000,  12000,  0,  0,  0],  
        [0,  0,  0,  0,  0,  0,  0,  0,  0],  
        [0,  0,  0,  0,  0,  0,  0,  0,  0],  
        [0,  0,  0,  0,  0,  0,  0,  0,  0],  
        [0,  0,  0,  0,  0,  0,  0,  0,  0],  
        [0,  0,  0,  9900,  9900,  9900,  0,  0,  0],
        [0,  0,  0,  9930,  9950,  9930,  0,  0,  0],
        [0,  0,  0, 9950, 10000, 9950,  0,  0,  0],
    ]

    # 红相或士位置得分
    red_xiang_shi_pos_point = [
        [0,  0,  0,  0,  0,  0,  0,  0,  0],  
        [0,  0,  0,  0,  0,  0,  0,  0,  0],  
        [0,  0,  0,  0,  0,  0,  0,  0,  0],  
        [0,  0,  0,  0,  0,  0,  0,  0,  0],  
        [0,  0,  0,  0,  0,  0,  0,  0,  0],  
        [0,  0, 20,  0,  0,  0, 20,  0,  0],  
        [0,  0,  0,  0,  0,  0,  0,  0,  0],  
        [18,  0,  0, 20, 23, 20,  0,  0, 18],  
        [0,  0,  0,  0, 23,  0,  0,  0,  0],  
        [0,  0, 20, 20,  0, 20, 20,  0,  0],
    ]

    red_pos_point = {
        'z': red_bin_pos_point,
        'm': red_ma_pos_point,
        'c': red_che_pos_point,
        'j': red_jiang_pos_point,
        'p': red_pao_pos_point,
        'x': red_xiang_shi_pos_point,
        's': red_xiang_shi_pos_point
    }

    def __init__(self, team):
        self.team = team

    def get_single_chess_point(self, chess: Chess):
        if chess.team == self.team:
            return self.single_chess_point[chess.name]
        else:
            return -1 * self.single_chess_point[chess.name]

    def get_chess_pos_point(self, chess: Chess):
        red_pos_point_table = self.red_pos_point[chess.name]
        if chess.team == 'r':
            pos_point = red_pos_point_table[chess.row][chess.col]
        else:
            pos_point = red_pos_point_table[9 - chess.row][chess.col]
        if chess.team != self.team:
            pos_point *= -1
        return pos_point

    def evaluate(self, chessboard: ChessBoard):
        point = 0
        for chess in chessboard.get_chess():
            point += self.get_single_chess_point(chess) #加上棋子本身的棋力值
            point += self.get_chess_pos_point(chess) #加上此时棋子位置的评分
        return point


class ChessMap(object):
    def __init__(self, chessboard: ChessBoard):
        self.chess_map = copy.deepcopy(chessboard.chessboard_map)


class MyAI(object):
    def __init__(self, user_team):
        self.team = user_team
        self.old_pos = [0, 0]
        self.new_pos = [0, 0]
        self.evaluate_class = Evaluate(self.team)

    def get_next_step(self, chessboard: ChessBoard):
        self.old_pos = None #原始位置进行初始化
        self.new_pos = None #目标位置进行初始化
        self.alpha_beta(1,  -1* 0x3f3f3f3f, 0x3f3f3f3f, chessboard)
        #alpha_beta 剪枝函数实现（当前层数，负无穷，正无穷，棋盘本身）
        return self.old_pos[0], self.old_pos[1], self.new_pos[0], self.new_pos[1]



    def alpha_beta(self, depth, a, b, chessboard):
        # 首先判断是否到达最深搜索长度
        if depth >= MAX_DEPTH:
            return self.evaluate_class.evaluate(chessboard)
        # 计算对应分值后返回
        # 接下来就要遍历候选位置
        chess_condition = chessboard.get_chess() # 得到每个棋子在棋盘中的情况
        for chess in chess_condition:
            if depth % 2 == 1 and chess.team == self.team or \
            depth % 2 == 0 and chess.team != self.team:
                nxt_pos = chessboard.get_put_down_position(chess) # 得到该棋子的可能落子情况
                for nxt_row, nxt_col in nxt_pos:
                    old_row, old_col = chess.row, chess.col # 保存选中棋子的初始位置
                    tmp = chessboard.chessboard_map[nxt_row][nxt_col] # 得到新位置的棋子信息
                    chessboard.chessboard_map[nxt_row][nxt_col] = chessboard.chessboard_map[old_row][old_col] # 将棋子落子到目标位置
                    chessboard.chessboard_map[nxt_row][nxt_col].update_position(nxt_row, nxt_col)
                    chessboard.chessboard_map[old_row][old_col] = None # 将棋盘上原棋子的位置置为空
                    # 继续往下探索可能的步骤
                    value = self.alpha_beta(depth+1, a, b, chessboard)
                    # 棋盘状态的回溯
                    chessboard.chessboard_map[old_row][old_col] = chessboard.chessboard_map[nxt_row][nxt_col]
                    chessboard.chessboard_map[old_row][old_col].update_position(old_row, old_col)
                    chessboard.chessboard_map[nxt_row][nxt_col] = tmp
                    # 接下来进行剪枝过程
                    if depth & 1 == 1: #现在为
                        if value > a:
                            a = value
                            if depth == 1:
                                self.old_pos = [chess.row, chess.col]
                                self.new_pos = [nxt_row, nxt_col]
                    else :
                        b = min(b, value)
                    if b <= a:
                        return a if depth & 1 ==1 else b 
                    
        return a if depth & 1 ==1 else b

