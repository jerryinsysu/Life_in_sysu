import os
import torch
import matplotlib.pyplot as plt
from torch import nn
from torchvision.datasets import ImageFolder
from torchvision import transforms
from torch.utils.data import DataLoader
from torch.optim import SGD

EPOCH = 20
LR = 0.0001

train_losses = []
train_accs = []
test_accs = []

def load_dataset(data_dir, batch_size=32, image_size=(224, 224)):
    """
    读取数据集并返回训练集和测试集。
    
    参数:
    data_dir (str): 数据集的根目录路径
    batch_size (int): 每个批次的样本数
    image_size (tuple): 图像大小
    
    返回:
    train_loader, test_loader, class_names
    """
    
    # 定义数据预处理转换
    transform = transforms.Compose([
        transforms.Resize(image_size),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])
    
    # 读取训练集
    train_dataset = ImageFolder(os.path.join(data_dir, 'train'), transform=transform)
    
    # 创建训练集数据加载器
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    
    # 读取测试集
    test_dataset = ImageFolder(os.path.join(data_dir, 'test'), transform=transform)
    
    # 创建测试集数据加载器
    test_loader = DataLoader(test_dataset, batch_size=batch_size)
    
    # 获取类名
    class_names = train_dataset.classes
    
    return train_loader, test_loader, class_names

# 使用示例
data_dir = 'cnn图片'
train_loader, test_loader, class_names = load_dataset(data_dir)



class CNN(nn.Module):
    def __init__(self):
        super(CNN, self).__init__()
        self.conv1 = nn.Sequential(         # input shape (3, 224, 224)
            nn.Conv2d(
                in_channels=3,              # input height
                out_channels=16,            # n_filters
                kernel_size=5,              # filter size
                stride=1,                   # filter movement/step
                padding=2,                  # if want same width and length of this image after Conv2d, padding=(kernel_size-1)/2 if stride=1
            ),                              # output shape (16, 224, 224)
            nn.ReLU(),                      # activation
            nn.MaxPool2d(kernel_size=2),    # choose max value in 2x2 area, output shape (16, 112, 112)
        )
        self.conv2 = nn.Sequential(         # input shape (16, 112, 112)
            nn.Conv2d(16, 32, 5, 1, 2),     # output shape (16, 112, 112)
            nn.ReLU(),                      # activation
            nn.MaxPool2d(kernel_size=2),                # output shape (32, 56, 56)
        )

        self.conv3 = nn.Sequential(         # input shape (32, 56, 56)
            nn.Conv2d(32, 64, 3, 1, 1),     # output shape (64, 56, 56)
            nn.ReLU(),                      # activation
            nn.MaxPool2d(kernel_size=2),                # output shape (64, 28, 28)
        )

        #self.out = nn.Linear(64 * 28 * 28, 5)   # fully connected layer, output 10 classes
        self.out = nn.Linear(32 * 56 * 56, 5)

    def forward(self, x):
        x = self.conv1(x)
        x = self.conv2(x)
        #x = self.conv3(x)
        x = x.view(x.size(0), -1)           # flatten the output of conv2 to (batch_size, 32 * 56 * 56)
        output = self.out(x)
        return output    # return x for visualization


cnn = CNN()
#print(cnn)  # net architecture

##optimizer = torch.optim.Adam(cnn.parameters(), lr=LR)   # optimize all cnn parameters
loss_func = nn.CrossEntropyLoss()                       # the target label is not one-hotted
optimizer = SGD(cnn.parameters(), lr=LR, momentum=0.9)

# training and testing
for epoch in range(EPOCH):
    for step, (b_x, b_y) in enumerate(train_loader):   # gives batch data, normalize x when iterate train_loader

        output = cnn(b_x)              # cnn output
        loss = loss_func(output, b_y)   # cross entropy loss
        optimizer.zero_grad()           # clear gradients for this training step
        loss.backward()                 # backpropagation, compute gradients

        ## 试着进行梯度裁剪
        #torch.nn.utils.clip_grad_norm_(cnn.parameters(), max_norm=20, norm_type=2)

        optimizer.step()                # apply gradients

        if step % 50 == 0:
            total = 0 ##
            correct = 0 ##
            for test_x, test_y in test_loader: # 选出测试集的所有目标
                test_output = cnn(test_x)
                pred_y= torch.max(test_output, 1)[1].data.squeeze()
                correct += (pred_y == test_y).sum().item() ##
                total += test_y.size(0) ##

            accuracy = sum(pred_y == test_y) / test_y.size(0)
            print(f'Epoch: {epoch} | train loss: {loss.item():.4f} | test accuracy: {accuracy:.2f}%')
            #train_losses.append(loss.item()) 
            # 记录测试集上的准确率
            test_accs.append(accuracy)   

        if step % 50 == 0: # 每50步就查看一下当前的测试集正确率
            total = 0
            correct = 0
            for train_x, train_y in train_loader:
                train_output = cnn(train_x)
                pred_y = torch.max(train_output, 1)[1].data.squeeze()
                correct += (pred_y == train_y).sum().item()
                total += train_y.size(0)

            accuracy = sum(pred_y == train_y) / train_y.size(0)
            ##print(f'Epoch: {epoch} | train loss: {loss.item():.4f} | train accuracy: {accuracy:.2f}%')
            train_losses.append(loss.item()) 
            train_accs.append(accuracy)         

# print 10 predictions from test data
for i, (test_x, test_y) in enumerate(test_loader):
    test_output = cnn(test_x)
    pred_y = torch.max(test_output, 1)[1].cpu().numpy()
    for j in range(test_x.size(0)):
        print(f'Prediction: {class_names[pred_y[j]]}')
        print(f'Ground Truth: {class_names[test_y[j].numpy()]}')


plt.figure(figsize=(12, 6))

# 绘制训练损失曲线
plt.subplot(1, 2, 1)
plt.plot(train_losses)
plt.title('Training Loss')
plt.xlabel('Iteration')
plt.ylabel('Loss')

# 绘制准确率曲线
plt.subplot(1, 2, 2)
plt.plot(train_accs, label='Train Accuracy')
plt.plot(test_accs, label='Test Accuracy')
plt.title('Accuracy')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.legend()

plt.show()