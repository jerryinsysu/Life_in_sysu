from pathlib import Path
import torch as th
import torch.nn as nn
import torch.optim as optim
import numpy as np
import gym
from tensorboardX import SummaryWriter
import os
import argparse

# 选择设备
device = th.device("cuda:1" if th.cuda.is_available() else "cpu")

# 创建Q网络
class QNetwork(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(QNetwork, self).__init__()
        # 创建两个全连接层
        self.fc1 = nn.Linear(input_size, hidden_size)
        self.fc2 = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        x = th.relu(self.fc1(x))
        q = self.fc2(x)
        return q  # 返回Q值
    
# 经验回放池
class ReplayBuffer:
    def __init__(self, state_dim, buffer_size):
        self.buffer_size = buffer_size  # 缓冲区大小
        self.ptr = 0  # 索引
        self.size = 0  # 缓冲区中的样本数量
        # (s, a, r, s')作为一个样本也即输入的四元组
        self.state = np.zeros((buffer_size, state_dim))  # 存储状态
        self.action = np.zeros((buffer_size, 1))  # 存储动作
        self.reward = np.zeros((buffer_size, 1))  # 存储奖励
        self.next_state = np.zeros((buffer_size, state_dim))  # 存储下一个状态
        self.done = np.zeros((buffer_size, 1))  # 存储是否结束

    # 存储样本，将得到的样本存储到经验回放池中
    def push(self, state, action, reward, next_state, done):
        self.state[self.ptr] = state
        self.action[self.ptr] = action
        self.reward[self.ptr] = reward
        self.next_state[self.ptr] = next_state
        self.done[self.ptr] = done

        self.ptr = (self.ptr + 1) % self.buffer_size
        self.size = min(self.size + 1, self.buffer_size)

    def sample(self, batch_size):
        # 从经验回放池中随机采样batch_size个样本
        ind = np.random.randint(0, self.size, size=batch_size)
        return self.state[ind], self.action[ind], self.reward[ind], self.next_state[ind], self.done[ind]
    
    # 清空经验回放池
    def clean(self):
        self.ptr = 0
        self.size = 0

# 深度Q网络智能体
class DQN:
    def __init__(self, args, state_dim, hidden_size, action_dim):
        self.action_dim = action_dim  # 动作维度
        self.args = args
        self.eval_net = QNetwork(state_dim, hidden_size, action_dim).to(device)  # 创建Q在线网络
        self.target_net = QNetwork(state_dim, hidden_size, action_dim).to(device)  # 创建Q目标网络
        self.optimizer = optim.Adam(self.eval_net.parameters(), lr=args.lr)  # 优化器
        self.eps = args.eps  # epsilon贪心策略
        self.buffer = ReplayBuffer(state_dim, args.buffer_size)  # 创建经验回放池
        self.loss_fn = nn.MSELoss()  # 损失函数
        self.learn_step = 0

    # 选择动作
    def choose_action(self, state):
        if np.random.uniform() < self.eps:
            action = np.random.randint(0, self.action_dim)
        else:
            state = th.FloatTensor(state).unsqueeze(0).to(device)
            action = th.argmax(self.eval_net(state)).item()
        return action
    
    # 存储样本
    def store_transition(self, s, a, r, s_, done):
        self.buffer.push(s, a, r, s_, done)
    
    # 学习
    def learn(self):
        if self.eps > self.args.eps_min:
            self.eps *= self.args.eps_decay

        self.learn_step += 1 
        
        state, action, reward, next_state, dones = self.buffer.sample(self.args.batch_size)
        state = th.FloatTensor(state).to(device)
        action = th.LongTensor(action).to(device)
        reward = th.FloatTensor(reward).to(device)
        next_state = th.FloatTensor(next_state).to(device)
        dones = th.FloatTensor(dones).to(device)

        
        q_eval = self.eval_net(state).gather(-1, action) # q evaluate
        q_next = self.target_net(next_state).detach() 
        q_target = reward + self.args.gamma * (1 - dones) * th.max(q_next, dim=-1, keepdim=True)[0]  # Q_target = r + gamma * q_next
        loss = self.loss_fn(q_eval, q_target)

        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

        # 更新目标网络
        if self.learn_step % self.args.update_target == 0:
            self.target_net.load_state_dict(self.eval_net.state_dict())

    # 保存模型
    def save(self, path, num):
        os.makedirs(path, exist_ok=True)
        th.save(self.eval_net.state_dict(), os.path.join(path, f'eval_net_{num}.pth'))
        th.save(self.target_net.state_dict(), os.path.join(path, f'target_net_{num}.pth'))
        th.save(self.optimizer.state_dict(), os.path.join(path, f'optimizer_{num}.pth'))
        print('模型保存成功！')

# 训练
def main(args, logger=None):
    # 创建环境
    env = gym.make(args.env)
    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.n

    # 创建智能体
    agent = DQN(args, state_dim, hidden_size=args.hidden, action_dim=action_dim)

    # 训练
    for i_episode in range(args.n_episodes):
        s, _ = env.reset()
        ep_r = 0
        done = False
        while not done:
            a = agent.choose_action(s)
            s_, r, terminated, truncated, info = env.step(a)  # gym==0.26
            done = terminated or truncated
            agent.store_transition(s, a, r, s_, done)
            ep_r += r
            s = s_
            if agent.buffer.size >= args.buffer_size:
                agent.learn()
        logger.add_scalar('Reward', ep_r, i_episode)
        print(f'Episode: {i_episode}, Reward: {ep_r}')

        # if i_episode > 0 and i_episode / args.update_target == 5:
        #     os.makedirs(str(args.run_dir / 'incremental'), exist_ok=True)
        #     agent.save(str(args.run_dir / 'incremental'), i_episode)
        if i_episode % args.log_freq == 0:
            logger.add_scalar('Reward', ep_r, i_episode)
            agent.save(args.run_dir / 'incremental', i_episode)


# 定义网络需要的所有参数
if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--algorithm", default="DQN", type=str)
    parser.add_argument("--env", default="CartPole-v0", type=str)
    parser.add_argument("--seed", default=0, type=int)
    parser.add_argument("--lr", default=1e-3, type=float)
    parser.add_argument("--hidden", default=64, type=int)
    parser.add_argument("--n_episodes", default=1000, type=int)
    parser.add_argument("--gamma",default=0.99, type=float)
    parser.add_argument("--buffer_size", default=10000, type=int)
    parser.add_argument("--batch_size", default=128, type=int)
    parser.add_argument("--eps", default=1.0, type=float)
    parser.add_argument("--eps_min", default=0.05, type=float)
    parser.add_argument("--eps_decay", default=0.999, type=float)
    parser.add_argument("--update_target", default=100, type=int)
    parser.add_argument("--log_freq", default=100, type=int)
    parser.add_argument("--save_model", default=False, type=bool)
    parser.add_argument("--use_cuda", default=True, type=bool)

    args = parser.parse_args()

    model_dir = Path('./models') / args.algorithm / args.env
    if not model_dir.exists():
        curr_run = 'run1'
    else:
        exst_run_nums = [int(str(folder.name).split('run')[1]) for folder in model_dir.iterdir()
                         if str(folder.name).startswith('run')]
        if len(exst_run_nums) == 0:
            curr_run = 'run1'
        else:
            curr_run = 'run%i' % (max(exst_run_nums) + 1)

    run_dir = model_dir / curr_run
    log_dir = run_dir / 'logs'
    results_dir = run_dir / 'results'
    os.makedirs(str(log_dir))
    os.makedirs(str(results_dir))
    logger = SummaryWriter(str(log_dir))

    args.run_dir = run_dir

    main(args, logger)
