import numpy as np
import matplotlib.pyplot as plt
import random
import pandas as pd

class Life(object):  # 通过个体类的设立，可以帮助我们更好的计算评估函数
    def __init__(self, life):
        self.fitness = -1 # 每个个体初始化适应度均为-1
        self.life = life


class GeneticAlgTSP: # 遗传算法类

    def __init__(self, filename):  # 读入相应数据
        self.number,self.cities = self.read(filename) # 返回字典类型数据，键本身代表城市编号，而值则代表城市坐标
        self.population_size = 50 # 设定种群值
        self.geneLength = self.number # 基因长度先设为目前城市数量        
        self.population = self.init_population()
        self.pc = 0.75 # 交叉概率
        self.mutation_rate = 0.5 # 变异概率
        self.num_iterations = 10000 # 种群迭代数
        self.tournament_size = 5 # 锦标赛种群数
        self.good_rate = 0.7 # 父本中强者留下的概率
# 读取完对应数据，该如何进行下一步操作

    def read(self, filename): # 读取对应数据
        #df = pd.read_csv(filename, sep=" ", skiprows=10, header=None)
        # df = pd.read_csv(filename, sep=" ", skiprows=10, header=None)
        # index = np.array(df[0])
        # index = index.tolist()
        # city_dict = {} # 准备一个字典
        # for i in range(len(index)):
        #     city_dict[index[i]] = np.array(df.iloc[i,1:])
        # return len(index),city_dict
        with open(filename, 'r') as file:
            lines = file.readlines()
            cities_data = []
            cities_dict = {}  # 新增的字典用于存储城市标号和数据
            for line in lines:
                if any(char.isalpha() or char == ':' for char in line):
                    continue
                parts = line.split()
                city_index = int(parts[0])  # 假设城市标号在每行数据的第一个位置
                city_data = list(map(float, parts[1:]))
                cities_data.append(city_data)
                cities_dict[city_index] = city_data  # 将城市标号和对应数据存入字典
                cities_array = np.array(cities_data)
        return len(cities_array), cities_dict
    
    def init_population(self): # 初始化种群
         #num_of_cities = self.number # 一共有这么多城市
         population = []
         for i in range(self.population_size):
            individual = np.random.permutation(self.geneLength) # 生成一段长度固定的随机序列，且范围是从0开始，但是城市标号是从1开始
            life = Life(individual)  # 将这段基因代码生成为一个个体
            population.append(life) # 生成以城市标号为代表的种群
         return population

    def Judge(self): # 编写对应评估函数
        self.bounds = 0.0 # 个体适应度的总值
        self.best = self.population[0] # 初始化时，先把第一个个体作为最优个体
        for individual in self.population:
            individual.fitness = 1/(self.Distance(individual))
            self.bounds += individual.fitness
  

    def Distance(self, life): # 计算城市之间的欧几里得距离
        total_distance = 0.0
        for i in range(self.geneLength-1): # 由于随机序列从0开始，所以我们选择给每一个随机值+1，作为城市值
            current_city = self.cities[life.life[i]+1]
            next_city = self.cities[life.life[i+1]+1]
            cur_x = current_city[0]
            cur_y = current_city[1]
            nxt_x = next_city[0]
            nxt_y = next_city[1]
            distance = ((nxt_x - cur_x) ** 2 + (nxt_y - cur_y) ** 2) ** 0.5
            total_distance += distance # 先加上整条路径长度
        # 计算最后一个节点到第一个节点的距离（闭环）
        start_city = self.cities[life.life[0]+1]
        end_city = self.cities[life.life[-1]+1]
        x1 = start_city[0]
        x2 = end_city[0]
        y1 = start_city[1]
        y2 = end_city[1]
        distance = ((x2 - x1) ** 2 + (y2 - y1) ** 2) ** 0.5
        total_distance += distance
        return total_distance
    
    def nature_select(self, population, tournament_size): # 采用锦标赛原理来实现自然选择
        # 选择父代
        new_population = []
        self.Judge()
        while len(new_population) < len(population):
            tournament_list = random.sample(range(0,self.population_size),tournament_size)
            tournament_fit = []

            for i in tournament_list:
                tournament_fit.append(population[i].fitness)
            tournament_df = pd.DataFrame \
            ([tournament_list, tournament_fit]).transpose().sort_values(by=1, ascending=False).reset_index(drop=True)
            
            best_life = population[int(tournament_df.iloc[0, 0])] # 取出表现最好的个体
            new_population.append(best_life)

        new_population = new_population[0:int(self.population_size*self.good_rate)]


        return new_population
    

    #def crossover(self, parents1, parents2): # 进行交叉繁殖
    def crossover(self, parents1): # 进行交叉繁殖
        count = self.population_size - len(parents1) # 生成的孩子数量
        children = []

        while len(children) < count:
            # 进行初始化
            k = random.randint(0,len(parents1)-1) 
            l = random.randint(0,len(parents1)-1)
            child = [None] * self.geneLength
            parent1 = parents1[k] # 注意此时parent本身为Life类型
            parent2 = parents1[l]
            flag = 0
            # 判断是否要进行交叉
            if random.random() > self.pc:
                #child = parent1.life.copy()
                child = parent1.life.copy()
                child = Life(child)
                flag = 1

            else:
                # parent1
                start_pos = random.randint(0,len(parent1.life)-1) # 保证下标都能被取到
                end_pos = random.randint(0,len(parent1.life)-1)
                if start_pos > end_pos:
                    tmp = end_pos
                    end_pos = start_pos
                    start_pos = tmp
                # for i in range(start_pos, end_pos+1):
                #     child.append(parent1[i])
                child[start_pos:end_pos+1] = parent1.life[start_pos:end_pos+1].copy()
                # parent 2
                list1 = list(range(end_pos + 1, len(parent2.life)))
                list2 = list(range(0, start_pos))
                list_index = list1 + list2
                j = -1
                for i in list_index:
                    for j in range(j+1, len(parent2.life)):
                        if parent2.life[j] not in child:
                            child[i] = parent2.life[j]
                            break
            if flag == 0: 
                child = Life(np.array(child))
            children.append(child)
        return children
        #     while True:
        #         male_index = random.randint(0, len(parents1) - 1)
        #         female_index = random.randint(0, len(parents2) - 1)        
        #         if male_index != female_index:
        #             break
        #     male = parents1[male_index] 
        #     female = parents2[female_index]
        #     left = random.randint(0, len(male.life) - 2)
        #     right = random.randint(left, len(male.life) - 1)
        #     gen_male = male.life[left:right]
        #     gen_female = female.life[left:right]
        #     child_a = []
        #     child_b = []         

        #     len_ca = 0
        #     for g in male.life:
        #         if len_ca == left:
        #             child_a.extend(gen_female)
        #             len_ca += len(gen_female)
        #         if g not in gen_female:
        #             child_a.append(g)
        #             len_ca += 1

        #     len_cb = 0
        #     for g in female.life:
        #         if len_cb == left:
        #             child_b.extend(gen_male)
        #             len_cb += len(gen_male)
        #         if g not in gen_male:
        #             child_b.append(g)
        #             len_cb += 1

        #     child = child_a + child_b
        #     children.append(Life(child))

        # return children





    def mutate(self, children): # 执行变异操作
        for i in range(len(children)):
            if random.random() < self.mutation_rate: # 执行变异操作
                while True:
                    u = random.randint(0, self.geneLength-1)
                    v = random.randint(0, self.geneLength-1)
                    if u != v :
                        break
                tmp = children[i].life[u]
                children[i].life[u] = children[i].life[v]
                children[i].life[v] = tmp


    def get_result(self, population): # 获得相应结果
        grad = [[x.life, self.Distance(x)] for x in population]
        grad = sorted(grad, key=lambda x: x[1])
        return grad[0][0], grad[0][1]       




    def iterate(self, num_iteratons):
        i = 0
        while i < num_iteratons:
            # 进行自然选择
            parents1 = self.nature_select(self.population, self.tournament_size)
            #parents2 = self.nature_select(self.population, self.tournament_size)
            # 繁殖操作
            #children = self.crossover(parents1, parents2)
            children = self.crossover(parents1)
            # 变异操作
            self.mutate(children)
            # 更新操作
            self.population = parents1 + children # 随机指定一方作为父本保留
            result_cur_best, dist_cur_best = self.get_result(self.population)
            distance_list.append(dist_cur_best)
            i = i + 1
            print(i)
        return result_cur_best, dist_cur_best


if __name__ == "__main__":

    city = GeneticAlgTSP("uy734.tsp") # 创造出对应实例
    distance_list = []
    result_cur_best, dist_cur_best = city.get_result(city.population)
    distance_list.append(dist_cur_best)
    result_cur_best, dist_cur_best = city.iterate(city.num_iterations)
    distance_list.append(dist_cur_best)
    for i in range(len(result_cur_best)):
        result_cur_best[i] += 1
    result_path = list(result_cur_best)
    result_path.append(result_path[0])
    for i in range(len(result_path)):
        print(result_path[i], end="")
        if i != len(result_path)-1:
            print('-', end="")
    print('\n')
    print(dist_cur_best)
    X = []
    Y = []
    for i in result_path:
        data=city.cities[result_path[i]]
        X.append(data[0])
        Y.append(data[1])
    plt.rcParams['font.sans-serif'] = 'SimHei'  # 设置中文显示
    plt.figure(1)
    plt.plot(X, Y, linestyle='-', marker='o', color='blue', label='Path')
    for i in range(len(X)):
        plt.text(X[i] + 0.05, Y[i] + 0.05, str(result_path[i]), color='red')
    plt.xlabel('横坐标')
    plt.ylabel('纵坐标')
    plt.title('轨迹图')
    plt.figure(2)
    plt.plot(np.array(distance_list))
    plt.title('优化过程')
    plt.ylabel('最优值')
    plt.xlabel('代数({}->{})'.format(0, city.num_iterations))
    plt.show()

