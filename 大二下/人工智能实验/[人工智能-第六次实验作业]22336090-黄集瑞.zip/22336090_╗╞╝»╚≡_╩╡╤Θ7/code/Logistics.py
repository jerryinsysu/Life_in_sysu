import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


## 首先进行读取数据
def loadDataSet(filename):
    dataMat = []
    labelMat = []
    fr = open(filename)
    for line in fr.readlines():
        if any(char.isalpha() or char == ':' for char in line):
            continue
        line_list = line.strip().split(',')
        dataMat.append([int(line_list[0]), int(line_list[1])])
        labelMat.append(int(line_list[2]))
        data_array = np.array(dataMat)
        label_array = np.array(labelMat)
    return data_array, label_array

## 利用逻辑回归作为分类算法，采用sigmoid函数使得输出值转换至(0,1)区间内
def sigmoid(x):
    
    return 1 / (1 + np.exp(-x))

## 进行特征归一化
def standardization(X):
    X_mean = X.mean(axis=0)
    X_std = X.std(axis=0)
    X_scaled = (X - X_mean) / X_std
    return X_scaled   

# 特征归一化
def min_max_scaling(X):
    X_min = X.min(axis=0)
    X_max = X.max(axis=0)
    X_scaled = (X - X_min) / (X_max - X_min)
    return X_scaled

def max_abs_scaling(X):
    X_max_abs = np.abs(X).max(axis=0)
    X_scaled = X / X_max_abs
    return X_scaled

## 采用逻辑回归进行分类预测
def logistic_regression(X, y, num_of_iteration, learning_rate):
    m, n = X.shape # 分别求出 X 矩阵的行数以及特征数
    w = np.zeros(n) # 先将权重初始化为0
    b = 0 # 偏置也初始化为0
    losses = [] # 记录损失过程

    for i in range(num_of_iteration): # 进行迭代过程
        tmp = np.dot(X, w) + b # 计算线性函数值
        predictions = sigmoid(tmp) # 计算出分类概率
        error = predictions - y # 判断的误差
        loss = -np.mean(y * np.log(predictions) + (1-y) * np.log(1-predictions)) # 利用交叉熵函数来当作损失函数
        losses.append(loss)

        # 接下来进行梯度更新
        dw = np.dot(error, X)/m
        db = np.mean(error)
        # 利用梯度下降的方式来优化
        w -= learning_rate * dw 
        b -= learning_rate * db

    return w, b, losses


filename = "data.csv"
X, y = loadDataSet(filename)
#X = standardization(X) # 进行特征的数据归一化
# 数据集可视化
plt.figure(1)
plt.scatter(X[y == 0][:, 0], X[y == 0][:, 1], color='red', label='Not Purchased')
plt.scatter(X[y == 1][:, 0], X[y == 1][:, 1], color='blue', label='Purchased')
plt.title('Normalized Data Visualization')
plt.xlabel('Age')
plt.ylabel('Estimated Salary')
plt.legend()


X = standardization(X) # 进行特征的数据归一化
#X = min_max_scaling(X)
#X = max_abs_scaling(X)
w, b, losses = logistic_regression(X, y, num_of_iteration=300, learning_rate=0.03)
# 绘制损失曲线
plt.figure(2)
plt.plot(losses)
plt.title('Loss Curve - Logistic Regression')
plt.xlabel('Iteration')
plt.ylabel('Loss')

def predict(X, weights, b):
    return sigmoid(np.dot(X, weights) + b)

# 计算逻辑回归模型的准确率
predictions_lr = predict(X, w, b)
predictions_lr = (predictions_lr >= 0.5).astype(int)
accuracy_lr = np.mean(predictions_lr == y)
print(f'Logistic Regression Accuracy: {accuracy_lr}')

# 计算决策边界方程
decision_boundary = lambda x: (-w[0] * x - b) / w[1]

# 在原有散点图上绘制决策边界
plt.figure(3)
plt.scatter(X[y == 0][:, 0], X[y == 0][:, 1], color='red', label='Not Purchased')
plt.scatter(X[y == 1][:, 0], X[y == 1][:, 1], color='blue', label='Purchased')
plt.plot(X[:, 0], decision_boundary(X[:, 0]), color='green', label='Decision Boundary')
plt.title('Normalized Data Visualization with Decision Boundary')
plt.xlabel('Age')
plt.ylabel('Estimated Salary')
plt.legend()


plt.show()



