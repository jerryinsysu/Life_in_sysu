import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

## 首先进行读取数据
def loadDataSet(filename):
    dataMat = []
    labelMat = []
    fr = open(filename)
    for line in fr.readlines():
        if any(char.isalpha() or char == ':' for char in line):
            continue
        line_list = line.strip().split(',')
        dataMat.append([int(line_list[0]), int(line_list[1])])
        labelMat.append(int(line_list[2]))
        data_array = np.array(dataMat)
        label_array = np.array(labelMat)
    return data_array, label_array

## 利用单层感知机来实现分类算法，采用sign作为激活函数
def sign(x):
    if x > 0:
        return 1
    elif x == 0:
        return 0
    else:
        return -1 

## 进行特征归一化
def standardization(X):
    X_mean = X.mean(axis=0)
    X_std = X.std(axis=0)
    X_scaled = (X - X_mean) / X_std
    return X_scaled   

## 采用感知机进行分类预测
def perceptron(X, y, num_of_iteration, learning_rate):
    m,n = X.shape # 分别求出 X 矩阵的行数以及特征数
    w = np.zeros(n) # 先将权重初始化为0
    b = 0 # 偏置也初始化为0
    losses = [] # 记录损失过程
    #num = 0 # 误分类点的个数

    for i in range(num_of_iteration):
        # 对每一个样本都进行计算
        loss_value = 0
        for j in range(m):
            # 接下来判断这个值是不是误差点
            if y[j] * sign(np.dot(X[j], w) + b) <= 0: # 说明此时是误分类点
                # 进行梯度更新
                dw = -1 * y[j] * X[j]
                db = -1 * y[j]
                #num += 1
                w -= learning_rate * dw
                b -= learning_rate * db
                # 计算损失
                loss_value += -y[j] * (np.dot(X[j], w) + b)
            else:
                continue
        losses.append(loss_value)

    return w, b, losses


filename = "data.csv"
X, y = loadDataSet(filename)
y[y==0] = -1
#X = standardization(X) # 进行特征的数据归一化
# 数据集可视化
plt.figure(1)
plt.scatter(X[y == -1][:, 0], X[y == -1][:, 1], color='red', label='Not Purchased')
plt.scatter(X[y == 1][:, 0], X[y == 1][:, 1], color='blue', label='Purchased')
plt.title('Normalized Data Visualization')
plt.xlabel('Age')
plt.ylabel('Estimated Salary')
plt.legend()

X = standardization(X) # 进行特征的数据归一化
w, b, losses = perceptron(X, y, num_of_iteration=1000, learning_rate=0.01)
# 绘制损失曲线
plt.figure(2)
plt.plot(losses)
plt.title('Loss Curve - Logistic Regression')
plt.xlabel('Iteration')
plt.ylabel('Loss')

# 计算决策边界方程
decision_boundary = lambda x: (-w[0] * x - b) / w[1]

# 在原有散点图上绘制决策边界
plt.figure(3)
plt.scatter(X[y == -1][:, 0], X[y == -1][:, 1], color='red', label='Not Purchased')
plt.scatter(X[y == 1][:, 0], X[y == 1][:, 1], color='blue', label='Purchased')
plt.plot(X[:, 0], decision_boundary(X[:, 0]), color='green', label='Decision Boundary')
# 绘制决策边界
plt.title('Perceptron Decision Boundary')
plt.xlabel('Age')
plt.ylabel('Estimated Salary')
plt.legend()


# 进行预测准确率的计算

# 计算感知机模型的准确率
predictions_perceptron = (np.dot(X, w) + b > 0).astype(int)
predictions_perceptron[predictions_perceptron == 0] = -1
accuracy_perceptron = np.mean(predictions_perceptron == y)
print(f'Perceptron Accuracy: {accuracy_perceptron}')

plt.show()


