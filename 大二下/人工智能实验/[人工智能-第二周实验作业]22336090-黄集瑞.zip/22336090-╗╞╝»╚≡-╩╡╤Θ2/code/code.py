class StuData():
    def __init__(self,filename):
        self.data = []
        try:
            with open(filename) as file_obj:
                for info in file_obj.read().splitlines(): 
                    info = info.split(sep=" ") 
                    info[3] = int(info[3])
                    self.data.append(list(info))
        except FileNotFoundError:
            print(f"File {filename} not found.")
                
    def AddData(self, name, stu_num, gender, age):
        temp = [name, stu_num, gender, age]
        self.data.append(temp)
        
    def SortData(self, standard): #利用lambda函数来自定义排序
        if standard=='name':
            self.data.sort(key= lambda x:x[0] )
        elif standard=='stu_num':
            self.data.sort(key= lambda x:x[1] )
        elif standard=='gender':
            self.data.sort(key= lambda x:x[2] )
        elif standard=='age':
            self.data.sort(key= lambda x:x[3] )

    def ExportFile(self,filename):
        with open(filename,'w') as file_obj:
            for info in self.data:
                file_obj.write(str(info[0])+' '+str(info[1])+' '+str(info[2])+' '+str(info[3])+'\n')
            
my_data = StuData('student_data.txt')
print(my_data.data)
my_data.AddData(name="Bob", stu_num="003", gender="M", age=20)
print(my_data.data)
my_data.SortData('stu_num')
print(my_data.data)
my_data.ExportFile('new_stu_data.txt')